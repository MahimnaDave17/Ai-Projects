// Built-in fallback test so the engine runs immediately even without uploading a file
const BUILT_IN_SAMPLE = {
    examTitle: "Sample CBT Mock Test — Computer Science & Aptitude",
    durationMinutes: 10,
    positiveMarks: 4,
    negativeMarks: 1,
    questions: [
        {
            id: 1,
            section: "Computer Science",
            question: "Which data structure operates on the Last-In, First-Out (LIFO) principle?",
            options: ["Queue", "Stack", "Linked List", "Binary Heap"],
            answerIndex: 1,
            explanation: "A Stack pushes and pops elements from the top, following LIFO."
        },
        {
            id: 2,
            section: "Computer Science",
            question: "What is the worst-case time complexity of Binary Search?",
            options: ["O(1)", "O(n)", "O(log n)", "O(n log n)"],
            answerIndex: 2,
            explanation: "Each comparison halves the remaining search space, giving O(log n)."
        },
        {
            id: 3,
            section: "Quantitative Aptitude",
            question: "A train covers 180 km in 2.5 hours. What is its average speed?",
            options: ["65 km/h", "70 km/h", "72 km/h", "75 km/h"],
            answerIndex: 2,
            explanation: "Speed = 180 / 2.5 = 72 km/h."
        },
        {
            id: 4,
            section: "Logical Reasoning",
            question: "Complete the number series: 2, 6, 12, 20, 30, ?",
            options: ["38", "40", "42", "44"],
            answerIndex: 2,
            explanation: "The pattern adds consecutive even numbers (+4, +6, +8, +10, +12)."
        }
    ]
};

// Engine State
let examData = null;
let currentIdx = 0;
let responses = []; // { selected: number|null, status: 'not-visited'|'not-answered'|'answered'|'marked' }
let secondsRemaining = 0;
let timerInterval = null;

// DOM Elements
const loaderScreen = document.getElementById('loader-screen');
const examScreen = document.getElementById('exam-screen');
const resultScreen = document.getElementById('result-screen');

const fileInput = document.getElementById('json-file-input');
document.getElementById('upload-btn').addEventListener('click', () => fileInput.click());
document.getElementById('demo-btn').addEventListener('click', () => startExam(BUILT_IN_SAMPLE));

fileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        if (!Array.isArray(parsed.questions) || parsed.questions.length === 0) {
            alert('Invalid question file: missing "questions" array.');
            return;
        }
        startExam(parsed);
    } catch (err) {
        alert('Could not parse JSON file. Please verify its syntax.');
    }
});

function startExam(data) {
    examData = {
        examTitle: data.examTitle || 'CBT Mock Assessment',
        durationMinutes: Number(data.durationMinutes) || 15,
        positiveMarks: Number(data.positiveMarks) ?? 4,
        negativeMarks: Number(data.negativeMarks) ?? 1,
        questions: data.questions
    };

    currentIdx = 0;
    responses = examData.questions.map(() => ({
        selected: null,
        status: 'not-visited'
    }));

    document.getElementById('exam-title').textContent = examData.examTitle;
    document.getElementById('marking-badge').textContent =
        `+${examData.positiveMarks} / -${examData.negativeMarks}`;

    loaderScreen.classList.add('hidden');
    resultScreen.classList.add('hidden');
    examScreen.classList.remove('hidden');

    startTimer(examData.durationMinutes * 60);
    loadQuestion(0);
}

function startTimer(totalSeconds) {
    clearInterval(timerInterval);
    secondsRemaining = totalSeconds;
    updateTimerDisplay();

    timerInterval = setInterval(() => {
        secondsRemaining--;
        updateTimerDisplay();
        if (secondsRemaining <= 0) {
            clearInterval(timerInterval);
            submitExam();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const mins = String(Math.floor(secondsRemaining / 60)).padStart(2, '0');
    const secs = String(secondsRemaining % 60).padStart(2, '0');
    const timerBox = document.getElementById('timer-display');
    timerBox.textContent = `${mins}:${secs}`;
    timerBox.classList.toggle('low-time', secondsRemaining <= 60);
}

function loadQuestion(index) {
    currentIdx = index;
    const q = examData.questions[index];
    const state = responses[index];

    // Mark as visited (not-answered) on first view
    if (state.status === 'not-visited') {
        state.status = 'not-answered';
    }

    document.getElementById('question-number').textContent =
        `Question ${index + 1} of ${examData.questions.length}`;
    document.getElementById('question-section').textContent = q.section || 'General';
    document.getElementById('question-text').textContent = q.question;

    const optionsList = document.getElementById('options-list');
    optionsList.innerHTML = '';

    const letters = ['A', 'B', 'C', 'D', 'E'];
    q.options.forEach((optText, optIdx) => {
        const div = document.createElement('div');
        div.className = 'option-item' + (state.selected === optIdx ? ' selected' : '');
        div.innerHTML = `
            <span class="option-prefix">${letters[optIdx] || optIdx + 1}</span>
            <span>${optText}</span>
        `;
        div.addEventListener('click', () => {
            state.selected = optIdx;
            loadQuestion(currentIdx);
        });
        optionsList.appendChild(div);
    });

    document.getElementById('prev-btn').disabled = index === 0;
    renderPalette();
}

function renderPalette() {
    const grid = document.getElementById('palette-grid');
    grid.innerHTML = '';

    let counts = { answered: 0, 'not-answered': 0, 'not-visited': 0, marked: 0 };

    responses.forEach((resp, idx) => {
        counts[resp.status]++;
        const btn = document.createElement('button');
        btn.className = `q-node ${resp.status}` + (idx === currentIdx ? ' current' : '');
        btn.textContent = idx + 1;
        btn.addEventListener('click', () => loadQuestion(idx));
        grid.appendChild(btn);
    });

    document.getElementById('count-answered').textContent = counts.answered;
    document.getElementById('count-not-answered').textContent = counts['not-answered'];
    document.getElementById('count-not-visited').textContent = counts['not-visited'];
    document.getElementById('count-marked').textContent = counts.marked;
}

// Navigation & Response Buttons
document.getElementById('save-next-btn').addEventListener('click', () => {
    const state = responses[currentIdx];
    state.status = state.selected !== null ? 'answered' : 'not-answered';
    if (currentIdx < examData.questions.length - 1) {
        loadQuestion(currentIdx + 1);
    } else {
        renderPalette();
    }
});

document.getElementById('mark-review-btn').addEventListener('click', () => {
    responses[currentIdx].status = 'marked';
    if (currentIdx < examData.questions.length - 1) {
        loadQuestion(currentIdx + 1);
    } else {
        renderPalette();
    }
});

document.getElementById('clear-response-btn').addEventListener('click', () => {
    responses[currentIdx].selected = null;
    responses[currentIdx].status = 'not-answered';
    loadQuestion(currentIdx);
});

document.getElementById('prev-btn').addEventListener('click', () => {
    if (currentIdx > 0) loadQuestion(currentIdx - 1);
});

document.getElementById('submit-exam-btn').addEventListener('click', () => {
    if (confirm('Are you sure you want to submit the test?')) {
        submitExam();
    }
});

function submitExam() {
    clearInterval(timerInterval);

    let correct = 0;
    let wrong = 0;
    let skipped = 0;

    const reviewContainer = document.getElementById('review-container');
    reviewContainer.innerHTML = '';

    examData.questions.forEach((q, idx) => {
        const userAns = responses[idx].selected;
        let statusTag = '';

        if (userAns === null) {
            skipped++;
            statusTag = '<span style="color:#64748b">Unattempted</span>';
        } else if (userAns === q.answerIndex) {
            correct++;
            statusTag = `<span style="color:#16a34a">Correct (+${examData.positiveMarks})</span>`;
        } else {
            wrong++;
            statusTag = `<span style="color:#dc2626">Incorrect (-${examData.negativeMarks})</span>`;
        }

        const item = document.createElement('div');
        item.className = 'review-item';
        item.innerHTML = `
            <div class="review-q">Q${idx + 1}. ${q.question}</div>
            <div class="review-meta">
                Your Answer: <b>${userAns !== null ? q.options[userAns] : 'None'}</b> |
                Correct Answer: <b>${q.options[q.answerIndex]}</b> | ${statusTag}
            </div>
            ${q.explanation ? `<div class="explanation-box"><strong>Explanation:</strong> ${q.explanation}</div>` : ''}
        `;
        reviewContainer.appendChild(item);
    });

    const totalScore = (correct * examData.positiveMarks) - (wrong * examData.negativeMarks);
    const attempted = correct + wrong;
    const accuracy = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;

    document.getElementById('res-score').textContent = totalScore;
    document.getElementById('res-correct').textContent = correct;
    document.getElementById('res-wrong').textContent = wrong;
    document.getElementById('res-skipped').textContent = skipped;
    document.getElementById('res-accuracy').textContent = `${accuracy}%`;

    examScreen.classList.add('hidden');
    resultScreen.classList.remove('hidden');
}

document.getElementById('restart-btn').addEventListener('click', () => {
    fileInput.value = '';
    resultScreen.classList.add('hidden');
    loaderScreen.classList.remove('hidden');
});