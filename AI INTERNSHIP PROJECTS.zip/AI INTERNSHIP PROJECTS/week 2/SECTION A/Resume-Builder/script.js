/**
 * Resume Builder Application Logic
 * Supports 3 templates:
 * 1. bw       -> Professional Black & White
 * 2. modern   -> Modern Blue Accent
 * 3. creative -> Creative Two-Column Layout
 * Includes live preview, localStorage persistence, validation, and clean A4 PDF export.
 */

document.addEventListener('DOMContentLoaded', () => {
  const STORAGE_KEY = 'resumeBuilderData_v1';

  // DOM References: Navigation & Controls
  const templateSelect = document.getElementById('template-select');
  const btnSave = document.getElementById('btn-save');
  const btnLoad = document.getElementById('btn-load');
  const btnExportPdf = document.getElementById('btn-export-pdf');
  const zoomInBtn = document.getElementById('zoom-in');
  const zoomOutBtn = document.getElementById('zoom-out');
  const zoomLevelDisplay = document.getElementById('zoom-level');

  // DOM References: Form & Lists
  const resumeForm = document.getElementById('resume-form');
  const experienceList = document.getElementById('experience-list');
  const educationList = document.getElementById('education-list');
  const projectsList = document.getElementById('projects-list');

  const btnAddExperience = document.getElementById('add-experience');
  const btnAddEducation = document.getElementById('add-education');
  const btnAddProject = document.getElementById('add-project');

  // DOM References: Personal Inputs
  const fullNameInput = document.getElementById('full-name');
  const jobTitleInput = document.getElementById('job-title');
  const emailInput = document.getElementById('email');
  const phoneInput = document.getElementById('phone');
  const locationInput = document.getElementById('location');
  const websiteInput = document.getElementById('website');
  const summaryInput = document.getElementById('summary');
  const skillsInput = document.getElementById('skills-input');

  // DOM References: Live Preview Sheet & Sections
  const resumePreview = document.getElementById('resume-preview');
  const previewName = document.getElementById('preview-name');
  const previewTitle = document.getElementById('preview-title');
  const previewEmail = document.getElementById('preview-email');
  const previewPhone = document.getElementById('preview-phone');
  const previewLocation = document.getElementById('preview-location');
  const previewWebsite = document.getElementById('preview-website');
  const previewSummary = document.getElementById('preview-summary');
  const previewSummarySection = document.getElementById('preview-summary-section');

  const previewExperienceSection = document.getElementById('preview-experience-section');
  const previewExperienceList = document.getElementById('preview-experience-list');

  const previewProjectsSection = document.getElementById('preview-projects-section');
  const previewProjectsList = document.getElementById('preview-projects-list');

  const previewEducationSection = document.getElementById('preview-education-section');
  const previewEducationList = document.getElementById('preview-education-list');

  const previewSkillsSection = document.getElementById('preview-skills-section');
  const previewSkillsList = document.getElementById('preview-skills-list');

  let currentZoom = 1.0;

  /* ==========================================================================
     1. Utility & Safe DOM Helpers
     ========================================================================== */

  function createEl(tag, className = '', text = '') {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text) el.textContent = text;
    return el;
  }

  function cleanUrlDisplay(url) {
    return url.replace(/^https?:\/\/(www\.)?/i, '').replace(/\/$/, '');
  }

  function showToast(message, isError = false) {
    const existing = document.getElementById('rb-toast');
    if (existing) existing.remove();

    const toast = createEl('div', '', message);
    toast.id = 'rb-toast';
    Object.assign(toast.style, {
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      backgroundColor: isError ? '#dc2626' : '#0f172a',
      color: '#ffffff',
      padding: '10px 18px',
      borderRadius: '6px',
      fontSize: '0.875rem',
      fontWeight: '600',
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
      zIndex: '9999',
      transition: 'opacity 0.25s ease'
    });

    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 250);
    }, 3000);
  }

  /* ==========================================================================
     2. Validation Logic
     ========================================================================== */

  function setFieldError(input, message) {
    if (!input) return;
    const parent = input.closest('.form-group');
    if (!parent) return;

    let errorEl = parent.querySelector('.field-error-msg');
    if (message) {
      input.style.borderColor = '#dc2626';
      input.setAttribute('aria-invalid', 'true');
      if (!errorEl) {
        errorEl = createEl('span', 'field-error-msg', message);
        Object.assign(errorEl.style, {
          color: '#dc2626',
          fontSize: '0.75rem',
          fontWeight: '600',
          marginTop: '2px'
        });
        parent.appendChild(errorEl);
      } else {
        errorEl.textContent = message;
      }
    } else {
      input.style.borderColor = '';
      input.removeAttribute('aria-invalid');
      if (errorEl) errorEl.remove();
    }
  }

  function validateForm() {
    let isValid = true;

    const nameVal = fullNameInput.value.trim();
    if (!nameVal) {
      setFieldError(fullNameInput, 'Full Name is required.');
      isValid = false;
    } else {
      setFieldError(fullNameInput, '');
    }

    const emailVal = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailVal) {
      setFieldError(emailInput, 'Email Address is required.');
      isValid = false;
    } else if (!emailRegex.test(emailVal)) {
      setFieldError(emailInput, 'Please enter a valid email address.');
      isValid = false;
    } else {
      setFieldError(emailInput, '');
    }

    const websiteVal = websiteInput.value.trim();
    if (websiteVal && !/^https?:\/\/.+\..+/i.test(websiteVal)) {
      setFieldError(websiteInput, 'Include http:// or https:// (e.g., https://linkedin.com/in/name)');
      isValid = false;
    } else {
      setFieldError(websiteInput, '');
    }

    return isValid;
  }

  /* ==========================================================================
     3. Repeatable Form Entry Builders (Add & Remove)
     ========================================================================== */

  function createInputGroup(labelText, id, name, placeholder, type = 'text', value = '') {
    const group = createEl('div', 'form-group');
    const label = createEl('label', '', labelText);
    label.setAttribute('for', id);

    let field;
    if (type === 'textarea') {
      field = createEl('textarea');
      field.rows = 3;
    } else {
      field = createEl('input');
      field.type = type;
    }

    field.id = id;
    field.name = name;
    field.placeholder = placeholder;
    field.value = value;

    group.appendChild(label);
    group.appendChild(field);
    return group;
  }

  function addExperienceEntry(data = {}) {
    const index = Date.now() + Math.floor(Math.random() * 1000);
    const article = createEl('article', 'repeatable-item');
    article.dataset.index = index;

    const grid = createEl('div', 'form-grid');
    grid.appendChild(createInputGroup('Job Title', `exp-role-${index}`, 'expRole[]', 'Software Developer', 'text', data.role || ''));
    grid.appendChild(createInputGroup('Company', `exp-company-${index}`, 'expCompany[]', 'TechNova Inc.', 'text', data.company || ''));
    grid.appendChild(createInputGroup('Start Date', `exp-start-${index}`, 'expStart[]', 'Jan 2023', 'text', data.start || ''));
    grid.appendChild(createInputGroup('End Date', `exp-end-${index}`, 'expEnd[]', 'Present', 'text', data.end || ''));

    const descGroup = createInputGroup(
      'Key Responsibilities & Achievements',
      `exp-desc-${index}`,
      'expDesc[]',
      '• Built scalable REST APIs...',
      'textarea',
      data.desc || ''
    );

    const removeBtn = createEl('button', 'btn-remove', 'Remove');
    removeBtn.type = 'button';
    removeBtn.setAttribute('aria-label', 'Remove experience entry');

    article.appendChild(grid);
    article.appendChild(descGroup);
    article.appendChild(removeBtn);
    experienceList.appendChild(article);
  }

  function addEducationEntry(data = {}) {
    const index = Date.now() + Math.floor(Math.random() * 1000);
    const article = createEl('article', 'repeatable-item');
    article.dataset.index = index;

    const grid = createEl('div', 'form-grid');
    grid.appendChild(createInputGroup('Degree / Certificate', `edu-degree-${index}`, 'eduDegree[]', 'B.S. in Computer Science', 'text', data.degree || ''));
    grid.appendChild(createInputGroup('Institution', `edu-school-${index}`, 'eduSchool[]', 'University of California', 'text', data.school || ''));
    grid.appendChild(createInputGroup('Graduation Year', `edu-year-${index}`, 'eduYear[]', '2022', 'text', data.year || ''));
    grid.appendChild(createInputGroup('GPA / Honors (Optional)', `edu-grade-${index}`, 'eduGrade[]', '3.8 / 4.0', 'text', data.grade || ''));

    const removeBtn = createEl('button', 'btn-remove', 'Remove');
    removeBtn.type = 'button';
    removeBtn.setAttribute('aria-label', 'Remove education entry');

    article.appendChild(grid);
    article.appendChild(removeBtn);
    educationList.appendChild(article);
  }

  function addProjectEntry(data = {}) {
    const index = Date.now() + Math.floor(Math.random() * 1000);
    const article = createEl('article', 'repeatable-item');
    article.dataset.index = index;

    const grid = createEl('div', 'form-grid');
    grid.appendChild(createInputGroup('Project Title', `proj-name-${index}`, 'projName[]', 'Cloud Task Manager', 'text', data.name || ''));
    grid.appendChild(createInputGroup('Live Link / Repository', `proj-link-${index}`, 'projLink[]', 'https://github.com/username/project', 'url', data.link || ''));

    const techGroup = createInputGroup('Technologies Used', `proj-tech-${index}`, 'projTech[]', 'React, Node.js, PostgreSQL', 'text', data.tech || '');
    const descGroup = createInputGroup(
      'Project Description',
      `proj-desc-${index}`,
      'projDesc[]',
      'Describe what you built and the problem it solved...',
      'textarea',
      data.desc || ''
    );

    const removeBtn = createEl('button', 'btn-remove', 'Remove');
    removeBtn.type = 'button';
    removeBtn.setAttribute('aria-label', 'Remove project entry');

    article.appendChild(grid);
    article.appendChild(techGroup);
    article.appendChild(descGroup);
    article.appendChild(removeBtn);
    projectsList.appendChild(article);
  }

  /* ==========================================================================
     4. Data Extraction from Form
     ========================================================================== */

  function collectFormData() {
    const experiences = Array.from(experienceList.querySelectorAll('.repeatable-item')).map(item => ({
      role: item.querySelector('input[name="expRole[]"]')?.value.trim() || '',
      company: item.querySelector('input[name="expCompany[]"]')?.value.trim() || '',
      start: item.querySelector('input[name="expStart[]"]')?.value.trim() || '',
      end: item.querySelector('input[name="expEnd[]"]')?.value.trim() || '',
      desc: item.querySelector('textarea[name="expDesc[]"]')?.value.trim() || ''
    }));

    const education = Array.from(educationList.querySelectorAll('.repeatable-item')).map(item => ({
      degree: item.querySelector('input[name="eduDegree[]"]')?.value.trim() || '',
      school: item.querySelector('input[name="eduSchool[]"]')?.value.trim() || '',
      year: item.querySelector('input[name="eduYear[]"]')?.value.trim() || '',
      grade: item.querySelector('input[name="eduGrade[]"]')?.value.trim() || ''
    }));

    const projects = Array.from(projectsList.querySelectorAll('.repeatable-item')).map(item => ({
      name: item.querySelector('input[name="projName[]"]')?.value.trim() || '',
      link: item.querySelector('input[name="projLink[]"]')?.value.trim() || '',
      tech: item.querySelector('input[name="projTech[]"]')?.value.trim() || '',
      desc: item.querySelector('textarea[name="projDesc[]"]')?.value.trim() || ''
    }));

    return {
      template: templateSelect.value,
      personal: {
        fullName: fullNameInput.value.trim(),
        jobTitle: jobTitleInput.value.trim(),
        email: emailInput.value.trim(),
        phone: phoneInput.value.trim(),
        location: locationInput.value.trim(),
        website: websiteInput.value.trim(),
        summary: summaryInput.value.trim()
      },
      experiences,
      education,
      projects,
      skills: skillsInput.value.trim()
    };
  }

  /* ==========================================================================
     5. Live Preview Rendering (Safe DOM Manipulation)
     ========================================================================== */

  function toggleContactItem(el, value, isLink = false) {
    if (value) {
      el.style.display = '';
      el.textContent = isLink ? cleanUrlDisplay(value) : value;
    } else {
      el.style.display = 'none';
      el.textContent = '';
    }
  }

  function updatePreview() {
    const data = collectFormData();

    // Apply Selected Template Class
    applyTemplate(data.template);

    // Personal Details
    previewName.textContent = data.personal.fullName || 'Your Name';
    previewTitle.textContent = data.personal.jobTitle || 'Professional Title';
    previewTitle.style.display = data.personal.jobTitle || !data.personal.fullName ? '' : 'none';

    toggleContactItem(previewEmail, data.personal.email);
    toggleContactItem(previewPhone, data.personal.phone);
    toggleContactItem(previewLocation, data.personal.location);
    toggleContactItem(previewWebsite, data.personal.website, true);

    // Professional Summary
    if (data.personal.summary) {
      previewSummarySection.style.display = '';
      previewSummary.textContent = data.personal.summary;
    } else {
      previewSummarySection.style.display = 'none';
    }

    // Work Experience
    previewExperienceList.replaceChildren();
    const validExperiences = data.experiences.filter(e => e.role || e.company || e.desc);
    if (validExperiences.length > 0) {
      previewExperienceSection.style.display = '';
      validExperiences.forEach(exp => {
        const itemDiv = createEl('div', 'resume-item');
        const headerDiv = createEl('div', 'item-header');
        const leftDiv = createEl('div');

        if (exp.role) leftDiv.appendChild(createEl('h3', '', exp.role));
        if (exp.company) leftDiv.appendChild(createEl('span', 'item-org', exp.company));
        headerDiv.appendChild(leftDiv);

        const dateRange = [exp.start, exp.end].filter(Boolean).join(' – ');
        if (dateRange) {
          headerDiv.appendChild(createEl('span', 'item-date', dateRange));
        }

        itemDiv.appendChild(headerDiv);
        if (exp.desc) {
          itemDiv.appendChild(createEl('p', 'item-description', exp.desc));
        }
        previewExperienceList.appendChild(itemDiv);
      });
    } else {
      previewExperienceSection.style.display = 'none';
    }

    // Projects
    previewProjectsList.replaceChildren();
    const validProjects = data.projects.filter(p => p.name || p.tech || p.desc);
    if (validProjects.length > 0) {
      previewProjectsSection.style.display = '';
      validProjects.forEach(proj => {
        const itemDiv = createEl('div', 'resume-item');
        const headerDiv = createEl('div', 'item-header');
        const leftDiv = createEl('div');

        if (proj.name) leftDiv.appendChild(createEl('h3', '', proj.name));
        if (proj.tech) leftDiv.appendChild(createEl('span', 'item-org', proj.tech));
        headerDiv.appendChild(leftDiv);

        if (proj.link) {
          headerDiv.appendChild(createEl('span', 'item-link', cleanUrlDisplay(proj.link)));
        }

        itemDiv.appendChild(headerDiv);
        if (proj.desc) {
          itemDiv.appendChild(createEl('p', 'item-description', proj.desc));
        }
        previewProjectsList.appendChild(itemDiv);
      });
    } else {
      previewProjectsSection.style.display = 'none';
    }

    // Education
    previewEducationList.replaceChildren();
    const validEducation = data.education.filter(ed => ed.degree || ed.school);
    if (validEducation.length > 0) {
      previewEducationSection.style.display = '';
      validEducation.forEach(ed => {
        const itemDiv = createEl('div', 'resume-item');
        const headerDiv = createEl('div', 'item-header');
        const leftDiv = createEl('div');

        if (ed.degree) leftDiv.appendChild(createEl('h3', '', ed.degree));
        if (ed.school) leftDiv.appendChild(createEl('span', 'item-org', ed.school));
        headerDiv.appendChild(leftDiv);

        const metaParts = [];
        if (ed.year) metaParts.push(ed.year);
        if (ed.grade) metaParts.push(`GPA: ${ed.grade}`);
        if (metaParts.length > 0) {
          headerDiv.appendChild(createEl('span', 'item-date', metaParts.join(' • ')));
        }

        itemDiv.appendChild(headerDiv);
        previewEducationList.appendChild(itemDiv);
      });
    } else {
      previewEducationSection.style.display = 'none';
    }

    // Skills
    previewSkillsList.replaceChildren();
    const skillsArray = data.skills
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    if (skillsArray.length > 0) {
      previewSkillsSection.style.display = '';
      skillsArray.forEach(skill => {
        previewSkillsList.appendChild(createEl('li', '', skill));
      });
    } else {
      previewSkillsSection.style.display = 'none';
    }
  }

  /* ==========================================================================
     6. Template Switcher (1: bw, 2: modern, 3: creative)
     ========================================================================== */

  function applyTemplate(templateName) {
    resumePreview.classList.remove('template-bw', 'template-modern', 'template-creative');
    const validTemplates = ['bw', 'modern', 'creative'];
    const selected = validTemplates.includes(templateName) ? templateName : 'modern';
    resumePreview.classList.add(`template-${selected}`);
  }

  /* ==========================================================================
     7. LocalStorage Save & Load
     ========================================================================== */

  function saveResumeToStorage() {
    if (!validateForm()) {
      showToast('Please fix the highlighted validation errors before saving.', true);
      return;
    }

    try {
      const data = collectFormData();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      showToast('Resume saved successfully!');
    } catch (err) {
      showToast('Unable to save resume. Storage may be full or disabled.', true);
    }
  }

  function populateFormWithData(data) {
    if (!data || typeof data !== 'object') return;

    if (data.template && ['bw', 'modern', 'creative'].includes(data.template)) {
      templateSelect.value = data.template;
      applyTemplate(data.template);
    }

    if (data.personal) {
      fullNameInput.value = data.personal.fullName || '';
      jobTitleInput.value = data.personal.jobTitle || '';
      emailInput.value = data.personal.email || '';
      phoneInput.value = data.personal.phone || '';
      locationInput.value = data.personal.location || '';
      websiteInput.value = data.personal.website || '';
      summaryInput.value = data.personal.summary || '';
    }

    experienceList.replaceChildren();
    if (Array.isArray(data.experiences) && data.experiences.length > 0) {
      data.experiences.forEach(exp => addExperienceEntry(exp));
    } else {
      addExperienceEntry();
    }

    educationList.replaceChildren();
    if (Array.isArray(data.education) && data.education.length > 0) {
      data.education.forEach(ed => addEducationEntry(ed));
    } else {
      addEducationEntry();
    }

    projectsList.replaceChildren();
    if (Array.isArray(data.projects) && data.projects.length > 0) {
      data.projects.forEach(proj => addProjectEntry(proj));
    } else {
      addProjectEntry();
    }

    skillsInput.value = data.skills || '';

    updatePreview();
  }

  function loadResumeFromStorage(silent = false) {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        if (!silent) showToast('No saved resume found in local storage.', true);
        return false;
      }

      const parsedData = JSON.parse(raw);
      populateFormWithData(parsedData);
      if (!silent) showToast('Saved resume loaded!');
      return true;
    } catch (err) {
      if (!silent) showToast('Failed to load saved resume data.', true);
      return false;
    }
  }

  /* ==========================================================================
     8. Event Listeners & Initialization
     ========================================================================== */

  // Instant Live Update on any form input or textarea change
  resumeForm.addEventListener('input', (e) => {
    if (e.target === fullNameInput || e.target === emailInput || e.target === websiteInput) {
      validateForm();
    }
    updatePreview();
  });

  // Instant Template Switching without losing data
  templateSelect.addEventListener('change', () => {
    applyTemplate(templateSelect.value);
  });

  // Add Entry Buttons
  btnAddExperience.addEventListener('click', () => {
    addExperienceEntry();
    updatePreview();
  });

  btnAddEducation.addEventListener('click', () => {
    addEducationEntry();
    updatePreview();
  });

  btnAddProject.addEventListener('click', () => {
    addProjectEntry();
    updatePreview();
  });

  // Event Delegation for Remove Buttons
  resumeForm.addEventListener('click', (e) => {
    if (e.target.classList.contains('btn-remove')) {
      const item = e.target.closest('.repeatable-item');
      const container = item?.parentElement;
      if (item && container) {
        if (container.children.length > 1) {
          item.remove();
        } else {
          item.querySelectorAll('input, textarea').forEach(field => {
            field.value = '';
          });
        }
        updatePreview();
      }
    }
  });

  // Save & Load Buttons
  btnSave.addEventListener('click', saveResumeToStorage);
  btnLoad.addEventListener('click', () => loadResumeFromStorage(false));

  // Export PDF Button Handler
  btnExportPdf.addEventListener('click', () => {
    if (!validateForm()) {
      showToast('Please enter your Name and a valid Email before exporting.', true);
      return;
    }

    // Ensure latest preview and template classes are synced
    updatePreview();

    // Temporarily reset zoom transform so A4 prints at exact 100% scale
    const savedTransform = resumePreview.style.transform;
    resumePreview.style.transform = 'none';

    // Set clean PDF filename via document title
    const originalTitle = document.title;
    const candidateName = fullNameInput.value.trim();
    if (candidateName) {
      document.title = `${candidateName} - Resume`;
    }

    // Restore zoom and title after print dialog finishes
    const cleanupAfterPrint = () => {
      resumePreview.style.transform = savedTransform;
      document.title = originalTitle;
      window.removeEventListener('afterprint', cleanupAfterPrint);
    };

    window.addEventListener('afterprint', cleanupAfterPrint);
    window.print();
  });

  // Preview Zoom Controls
  function updateZoom() {
    resumePreview.style.transform = `scale(${currentZoom})`;
    zoomLevelDisplay.textContent = `${Math.round(currentZoom * 100)}%`;
  }

  zoomInBtn.addEventListener('click', () => {
    if (currentZoom < 1.3) {
      currentZoom = Math.round((currentZoom + 0.1) * 10) / 10;
      updateZoom();
    }
  });

  zoomOutBtn.addEventListener('click', () => {
    if (currentZoom > 0.6) {
      currentZoom = Math.round((currentZoom - 0.1) * 10) / 10;
      updateZoom();
    }
  });

  // Initialize default template & restore saved data if available
  applyTemplate(templateSelect.value);
  loadResumeFromStorage(true);
});