/**
 * Bill Book - Step 1 Web Prototype
 * Uses localStorage temporarily; will be migrated to Capacitor SQLite in upcoming steps.
 */

document.addEventListener('DOMContentLoaded', () => {
  const STORAGE_KEYS = {
    SETTINGS: 'billbook_settings_v1',
    PRODUCTS: 'billbook_products_v1',
    BILLS: 'billbook_bills_v1'
  };

  // App State
  let settings = loadFromStorage(STORAGE_KEYS.SETTINGS, {
    shopName: 'My General Store',
    shopPhone: '',
    shopAddress: '',
    taxRate: 0
  });

  let products = loadFromStorage(STORAGE_KEYS.PRODUCTS, []);
  let bills = loadFromStorage(STORAGE_KEYS.BILLS, []);
  let currentBillItems = [];

  // DOM Elements: Header & Navigation
  const headerShopName = document.getElementById('header-shop-name');
  const headerDate = document.getElementById('header-date');
  const navItems = document.querySelectorAll('.nav-item');
  const views = document.querySelectorAll('.view');

  // DOM Elements: Dashboard
  const dashTodaySales = document.getElementById('dash-today-sales');
  const dashTodayBills = document.getElementById('dash-today-bills');
  const dashTotalBills = document.getElementById('dash-total-bills');
  const dashTotalProducts = document.getElementById('dash-total-products');
  const dashNewBillBtn = document.getElementById('dash-new-bill-btn');
  const dashRecentBills = document.getElementById('dash-recent-bills');

  // DOM Elements: New Bill
  const newBillNumberLabel = document.getElementById('new-bill-number-label');
  const billCustomerName = document.getElementById('bill-customer-name');
  const billCustomerPhone = document.getElementById('bill-customer-phone');
  const billProductSelect = document.getElementById('bill-product-select');
  const billItemName = document.getElementById('bill-item-name');
  const billItemPrice = document.getElementById('bill-item-price');
  const billItemQty = document.getElementById('bill-item-qty');
  const addBillItemBtn = document.getElementById('add-bill-item-btn');
  const billItemsCount = document.getElementById('bill-items-count');
  const billItemsList = document.getElementById('bill-items-list');
  const billSubtotal = document.getElementById('bill-subtotal');
  const billTaxLabel = document.getElementById('bill-tax-label');
  const billTaxAmount = document.getElementById('bill-tax-amount');
  const billGrandTotal = document.getElementById('bill-grand-total');
  const clearBillBtn = document.getElementById('clear-bill-btn');
  const saveBillBtn = document.getElementById('save-bill-btn');

  // DOM Elements: Products
  const productForm = document.getElementById('product-form');
  const prodNameInput = document.getElementById('prod-name');
  const prodPriceInput = document.getElementById('prod-price');
  const prodUnitInput = document.getElementById('prod-unit');
  const productsCount = document.getElementById('products-count');
  const productsList = document.getElementById('products-list');

  // DOM Elements: History
  const historySearch = document.getElementById('history-search');
  const historyList = document.getElementById('history-list');

  // DOM Elements: Settings
  const settingsForm = document.getElementById('settings-form');
  const settingShopName = document.getElementById('setting-shop-name');
  const settingShopPhone = document.getElementById('setting-shop-phone');
  const settingShopAddress = document.getElementById('setting-shop-address');
  const settingTaxRate = document.getElementById('setting-tax-rate');
  const loadSampleBtn = document.getElementById('load-sample-btn');
  const resetDataBtn = document.getElementById('reset-data-btn');

  // DOM Elements: Modal & Toast
  const billModal = document.getElementById('bill-modal');
  const modalBackdrop = document.getElementById('modal-backdrop');
  const closeModalBtn = document.getElementById('close-modal-btn');
  const closeModalFooterBtn = document.getElementById('close-modal-footer-btn');
  const modalBillTitle = document.getElementById('modal-bill-title');
  const modalBillBody = document.getElementById('modal-bill-body');
  const toastEl = document.getElementById('toast');

  /* ==========================================================================
     1. Storage & Formatting Helpers
     ========================================================================== */

  function loadFromStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function saveToStorage(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function formatCurrency(amount) {
    const num = Number(amount) || 0;
    return '₹' + num.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function getTodayDateString() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function formatDisplayDate(isoString) {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function getNextBillNumber() {
    if (bills.length === 0) return 1001;
    const maxNo = Math.max(...bills.map(b => Number(b.billNumber) || 1000));
    return maxNo + 1;
  }

  let toastTimer = null;
  function showToast(message) {
    toastEl.textContent = message;
    toastEl.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.add('hidden');
    }, 2600);
  }

  function createEl(tag, className = '', text = '') {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text) el.textContent = text;
    return el;
  }

  /* ==========================================================================
     2. Navigation
     ========================================================================== */

  function switchView(targetName) {
    views.forEach(view => {
      view.classList.toggle('active', view.id === `view-${targetName}`);
    });

    navItems.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.target === targetName);
    });

    if (targetName === 'dashboard') renderDashboard();
    if (targetName === 'new-bill') renderNewBillView();
    if (targetName === 'products') renderProducts();
    if (targetName === 'history') renderHistory();
    if (targetName === 'settings') renderSettingsForm();
  }

  navItems.forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.target));
  });

  dashNewBillBtn.addEventListener('click', () => switchView('new-bill'));

  document.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.nav));
  });

  /* ==========================================================================
     3. Header & Dashboard Rendering
     ========================================================================== */

  function renderHeader() {
    headerShopName.textContent = settings.shopName || 'My General Store';
    headerDate.textContent = new Date().toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  }

  function renderDashboard() {
    renderHeader();
    const todayStr = getTodayDateString();
    const todaysBills = bills.filter(b => b.dateKey === todayStr);
    const todaySalesSum = todaysBills.reduce((sum, b) => sum + (Number(b.grandTotal) || 0), 0);

    dashTodaySales.textContent = formatCurrency(todaySalesSum);
    dashTodayBills.textContent = String(todaysBills.length);
    dashTotalBills.textContent = String(bills.length);
    dashTotalProducts.textContent = String(products.length);

    dashRecentBills.replaceChildren();
    const recent = [...bills].reverse().slice(0, 5);

    if (recent.length === 0) {
      dashRecentBills.appendChild(
        createEl('p', 'empty-state', 'No bills created yet. Tap "+ Create New Bill" to start.')
      );
      return;
    }

    recent.forEach(bill => {
      const row = createEl('div', 'list-item');
      row.style.cursor = 'pointer';

      const main = createEl('div', 'item-main');
      main.appendChild(createEl('div', 'item-title', `Bill #${bill.billNumber} • ${bill.customerName}`));
      main.appendChild(createEl('div', 'item-meta', `${bill.items.length} item(s) • ${formatDisplayDate(bill.createdAt)}`));

      const right = createEl('div', 'item-right');
      right.appendChild(createEl('span', 'item-amount', formatCurrency(bill.grandTotal)));

      row.appendChild(main);
      row.appendChild(right);
      row.addEventListener('click', () => openBillReceiptModal(bill));
      dashRecentBills.appendChild(row);
    });
  }

  /* ==========================================================================
     4. Products Management
     ========================================================================== */

  function renderProducts() {
    productsCount.textContent = String(products.length);
    productsList.replaceChildren();

    if (products.length === 0) {
      productsList.appendChild(createEl('p', 'empty-state', 'No products saved yet.'));
      return;
    }

    products.forEach(prod => {
      const row = createEl('div', 'list-item');

      const main = createEl('div', 'item-main');
      main.appendChild(createEl('div', 'item-title', prod.name));
      main.appendChild(createEl('div', 'item-meta', `Unit: ${prod.unit || 'pcs'}`));

      const right = createEl('div', 'item-right');
      right.appendChild(createEl('span', 'item-amount', formatCurrency(prod.price)));

      const delBtn = createEl('button', 'icon-delete-btn', '✕');
      delBtn.type = 'button';
      delBtn.setAttribute('aria-label', `Delete ${prod.name}`);
      delBtn.addEventListener('click', () => {
        products = products.filter(p => p.id !== prod.id);
        saveToStorage(STORAGE_KEYS.PRODUCTS, products);
        renderProducts();
        showToast('Product removed');
      });

      right.appendChild(delBtn);
      row.appendChild(main);
      row.appendChild(right);
      productsList.appendChild(row);
    });
  }

  productForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = prodNameInput.value.trim();
    const price = parseFloat(prodPriceInput.value);
    const unit = prodUnitInput.value.trim() || 'pcs';

    if (!name || isNaN(price) || price < 0) {
      showToast('Enter a valid product name and price');
      return;
    }

    products.push({
      id: Date.now().toString(),
      name,
      price,
      unit
    });

    saveToStorage(STORAGE_KEYS.PRODUCTS, products);
    productForm.reset();
    prodUnitInput.value = 'pcs';
    renderProducts();
    showToast('Product saved!');
  });

  /* ==========================================================================
     5. New Bill & Billing Calculations
     ========================================================================== */

  function populateProductDropdown() {
    billProductSelect.replaceChildren();
    const defaultOpt = createEl('option', '', '-- Choose a product or enter custom below --');
    defaultOpt.value = '';
    billProductSelect.appendChild(defaultOpt);

    products.forEach(prod => {
      const opt = createEl('option', '', `${prod.name} (${formatCurrency(prod.price)} / ${prod.unit})`);
      opt.value = prod.id;
      billProductSelect.appendChild(opt);
    });
  }

  billProductSelect.addEventListener('change', () => {
    const selected = products.find(p => p.id === billProductSelect.value);
    if (selected) {
      billItemName.value = selected.name;
      billItemPrice.value = selected.price;
      billItemQty.value = 1;
    }
  });

  function renderNewBillView() {
    newBillNumberLabel.textContent = `Bill #${getNextBillNumber()}`;
    populateProductDropdown();
    renderCurrentBillItems();
  }

  function renderCurrentBillItems() {
    billItemsCount.textContent = `${currentBillItems.length} item${currentBillItems.length === 1 ? '' : 's'}`;
    billItemsList.replaceChildren();

    if (currentBillItems.length === 0) {
      billItemsList.appendChild(createEl('p', 'empty-state', 'No items added to this bill yet.'));
    } else {
      currentBillItems.forEach((item, idx) => {
        const row = createEl('div', 'list-item');

        const main = createEl('div', 'item-main');
        main.appendChild(createEl('div', 'item-title', item.name));
        main.appendChild(createEl('div', 'item-meta', `${item.qty} × ${formatCurrency(item.price)}`));

        const right = createEl('div', 'item-right');
        right.appendChild(createEl('span', 'item-amount', formatCurrency(item.total)));

        const removeBtn = createEl('button', 'icon-delete-btn', '✕');
        removeBtn.type = 'button';
        removeBtn.setAttribute('aria-label', `Remove ${item.name}`);
        removeBtn.addEventListener('click', () => {
          currentBillItems.splice(idx, 1);
          renderCurrentBillItems();
        });

        right.appendChild(removeBtn);
        row.appendChild(main);
        row.appendChild(right);
        billItemsList.appendChild(row);
      });
    }

    // Calculate Totals
    const subtotal = currentBillItems.reduce((sum, item) => sum + item.total, 0);
    const taxRate = Number(settings.taxRate) || 0;
    const taxAmount = (subtotal * taxRate) / 100;
    const grandTotal = subtotal + taxAmount;

    billSubtotal.textContent = formatCurrency(subtotal);
    billTaxLabel.textContent = `GST (${taxRate}%)`;
    billTaxAmount.textContent = formatCurrency(taxAmount);
    billGrandTotal.textContent = formatCurrency(grandTotal);
  }

  addBillItemBtn.addEventListener('click', () => {
    const name = billItemName.value.trim();
    const price = parseFloat(billItemPrice.value);
    const qty = parseInt(billItemQty.value, 10);

    if (!name) {
      showToast('Please enter an item name');
      return;
    }
    if (isNaN(price) || price < 0) {
      showToast('Please enter a valid price');
      return;
    }
    if (isNaN(qty) || qty < 1) {
      showToast('Quantity must be at least 1');
      return;
    }

    // Merge if same item name & price already in bill
    const existing = currentBillItems.find(
      i => i.name.toLowerCase() === name.toLowerCase() && i.price === price
    );

    if (existing) {
      existing.qty += qty;
      existing.total = existing.qty * existing.price;
    } else {
      currentBillItems.push({
        name,
        price,
        qty,
        total: price * qty
      });
    }

    billProductSelect.value = '';
    billItemName.value = '';
    billItemPrice.value = '';
    billItemQty.value = 1;

    renderCurrentBillItems();
    showToast('Item added to bill');
  });

  clearBillBtn.addEventListener('click', () => {
    currentBillItems = [];
    billCustomerName.value = '';
    billCustomerPhone.value = '';
    renderCurrentBillItems();
    showToast('Bill cleared');
  });

  saveBillBtn.addEventListener('click', () => {
    if (currentBillItems.length === 0) {
      showToast('Add at least one item before saving the bill');
      return;
    }

    const subtotal = currentBillItems.reduce((sum, item) => sum + item.total, 0);
    const taxRate = Number(settings.taxRate) || 0;
    const taxAmount = (subtotal * taxRate) / 100;
    const grandTotal = subtotal + taxAmount;

    const newBill = {
      id: Date.now().toString(),
      billNumber: getNextBillNumber(),
      customerName: billCustomerName.value.trim() || 'Walk-in Customer',
      customerPhone: billCustomerPhone.value.trim(),
      items: [...currentBillItems],
      subtotal,
      taxRate,
      taxAmount,
      grandTotal,
      dateKey: getTodayDateString(),
      createdAt: new Date().toISOString()
    };

    bills.push(newBill);
    saveToStorage(STORAGE_KEYS.BILLS, bills);

    // Reset New Bill Form
    currentBillItems = [];
    billCustomerName.value = '';
    billCustomerPhone.value = '';
    renderNewBillView();

    showToast(`Bill #${newBill.billNumber} saved!`);
    openBillReceiptModal(newBill);
  });

  /* ==========================================================================
     6. Bill History & Receipt Modal
     ========================================================================== */

  function renderHistory() {
    const query = historySearch.value.trim().toLowerCase();
    historyList.replaceChildren();

    const filtered = [...bills].reverse().filter(bill => {
      if (!query) return true;
      return (
        String(bill.billNumber).includes(query) ||
        bill.customerName.toLowerCase().includes(query) ||
        (bill.customerPhone && bill.customerPhone.includes(query))
      );
    });

    if (filtered.length === 0) {
      historyList.appendChild(createEl('p', 'empty-state', 'No matching bills found.'));
      return;
    }

    filtered.forEach(bill => {
      const card = createEl('div', 'history-card');
      const row = createEl('div', 'list-item');
      row.style.background = 'transparent';
      row.style.border = 'none';
      row.style.padding = '0';

      const main = createEl('div', 'item-main');
      main.appendChild(createEl('div', 'item-title', `Bill #${bill.billNumber} — ${bill.customerName}`));
      main.appendChild(createEl('div', 'item-meta', `${bill.items.length} item(s) • ${formatDisplayDate(bill.createdAt)}`));

      const right = createEl('div', 'item-right');
      right.appendChild(createEl('span', 'item-amount', formatCurrency(bill.grandTotal)));

      row.appendChild(main);
      row.appendChild(right);
      card.appendChild(row);
      card.addEventListener('click', () => openBillReceiptModal(bill));
      historyList.appendChild(card);
    });
  }

  historySearch.addEventListener('input', renderHistory);

  function openBillReceiptModal(bill) {
    modalBillTitle.textContent = `Invoice #${bill.billNumber}`;
    modalBillBody.replaceChildren();

    const shopHead = createEl('div', 'receipt-shop-head');
    shopHead.appendChild(createEl('h4', '', settings.shopName || 'My General Store'));
    if (settings.shopAddress) shopHead.appendChild(createEl('p', 'item-meta', settings.shopAddress));
    if (settings.shopPhone) shopHead.appendChild(createEl('p', 'item-meta', `Ph: ${settings.shopPhone}`));
    modalBillBody.appendChild(shopHead);

    const meta = createEl('div', 'receipt-meta');
    meta.appendChild(createEl('span', '', `Customer: ${bill.customerName}`));
    meta.appendChild(createEl('span', '', formatDisplayDate(bill.createdAt)));
    modalBillBody.appendChild(meta);

    const table = createEl('table', 'receipt-table');
    const thead = createEl('thead');
    const headRow = createEl('tr');
    ['Item', 'Qty', 'Rate', 'Total'].forEach(label => {
      headRow.appendChild(createEl('th', '', label));
    });
    thead.appendChild(headRow);
    table.appendChild(thead);

    const tbody = createEl('tbody');
    bill.items.forEach(item => {
      const tr = createEl('tr');
      tr.appendChild(createEl('td', '', item.name));
      tr.appendChild(createEl('td', '', String(item.qty)));
      tr.appendChild(createEl('td', '', formatCurrency(item.price)));
      tr.appendChild(createEl('td', '', formatCurrency(item.total)));
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    modalBillBody.appendChild(table);

    const totalsBox = createEl('div', 'bill-summary-box');
    const subRow = createEl('div', 'summary-row');
    subRow.appendChild(createEl('span', '', 'Subtotal'));
    subRow.appendChild(createEl('span', '', formatCurrency(bill.subtotal)));
    totalsBox.appendChild(subRow);

    if (bill.taxRate > 0) {
      const taxRow = createEl('div', 'summary-row');
      taxRow.appendChild(createEl('span', '', `GST (${bill.taxRate}%)`));
      taxRow.appendChild(createEl('span', '', formatCurrency(bill.taxAmount)));
      totalsBox.appendChild(taxRow);
    }

    const grandRow = createEl('div', 'summary-row total-row');
    grandRow.appendChild(createEl('span', '', 'Grand Total'));
    grandRow.appendChild(createEl('strong', '', formatCurrency(bill.grandTotal)));
    totalsBox.appendChild(grandRow);

    modalBillBody.appendChild(totalsBox);
    billModal.classList.remove('hidden');
  }

  function closeBillModal() {
    billModal.classList.add('hidden');
  }

  closeModalBtn.addEventListener('click', closeBillModal);
  closeModalFooterBtn.addEventListener('click', closeBillModal);
  modalBackdrop.addEventListener('click', closeBillModal);

  /* ==========================================================================
     7. Settings & Sample Data
     ========================================================================== */

  function renderSettingsForm() {
    settingShopName.value = settings.shopName || 'My General Store';
    settingShopPhone.value = settings.shopPhone || '';
    settingShopAddress.value = settings.shopAddress || '';
    settingTaxRate.value = settings.taxRate ?? 0;
  }

  settingsForm.addEventListener('submit', (e) => {
    e.preventDefault();
    settings = {
      shopName: settingShopName.value.trim() || 'My General Store',
      shopPhone: settingShopPhone.value.trim(),
      shopAddress: settingShopAddress.value.trim(),
      taxRate: Math.max(0, parseFloat(settingTaxRate.value) || 0)
    };
    saveToStorage(STORAGE_KEYS.SETTINGS, settings);
    renderHeader();
    showToast('Settings saved!');
  });

  loadSampleBtn.addEventListener('click', () => {
    const sampleItems = [
      { id: 's1', name: 'Basmati Rice (1 kg)', price: 110, unit: 'kg' },
      { id: 's2', name: 'Toor Dal (1 kg)', price: 145, unit: 'kg' },
      { id: 's3', name: 'Sunflower Cooking Oil (1 L)', price: 135, unit: 'ltr' },
      { id: 's4', name: 'Sugar (1 kg)', price: 46, unit: 'kg' },
      { id: 's5', name: 'Masala Tea Pack (250 g)', price: 120, unit: 'pcs' }
    ];

    sampleItems.forEach(sample => {
      const exists = products.some(p => p.name.toLowerCase() === sample.name.toLowerCase());
      if (!exists) products.push(sample);
    });

    saveToStorage(STORAGE_KEYS.PRODUCTS, products);
    renderDashboard();
    showToast('Sample shop products added!');
  });

  resetDataBtn.addEventListener('click', () => {
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.BILLS);

    settings = {
      shopName: 'My General Store',
      shopPhone: '',
      shopAddress: '',
      taxRate: 0
    };
    products = [];
    bills = [];
    currentBillItems = [];

    renderDashboard();
    renderSettingsForm();
    showToast('All local data cleared');
  });

  // Initial Load
  renderDashboard();
});