const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// UI Elements
const scoreEl = document.getElementById('score-val');
const coinEl = document.getElementById('coin-val');
const gameOverScreen = document.getElementById('game-over-screen');
const finalScoreEl = document.getElementById('final-score');
const finalCoinsEl = document.getElementById('final-coins');
const restartBtn = document.getElementById('restart-btn');

// Internal Canvas Resolution
const GAME_WIDTH = 400;
const GAME_HEIGHT = 750;
canvas.width = GAME_WIDTH;
canvas.height = GAME_HEIGHT;

// Road & Lane Configuration
const ROAD_WIDTH = 280;
const ROAD_X = (GAME_WIDTH - ROAD_WIDTH) / 2;
const LANE_WIDTH = ROAD_WIDTH / 3;
const LANES = [
    ROAD_X + LANE_WIDTH * 0.5,
    ROAD_X + LANE_WIDTH * 1.5,
    ROAD_X + LANE_WIDTH * 2.5
];

// Game State Variables
let roadSpeed = 6;
let stripeOffset = 0;
let score = 0;
let coinsCollected = 0;
let frameCount = 0;
let isGameOver = false;

let obstacles = [];
let coins = [];

// Input State
const keys = {
    ArrowLeft: false,
    ArrowRight: false,
    a: false,
    d: false
};

// Player Auto-Rickshaw
const player = {
    width: 52,
    height: 84,
    x: LANES[1] - 26,
    y: GAME_HEIGHT - 175,
    speed: 6.5,
    tilt: 0
};

// --- Event Listeners ---
window.addEventListener('keydown', (e) => {
    if (e.key in keys) keys[e.key] = true;
});

window.addEventListener('keyup', (e) => {
    if (e.key in keys) keys[e.key] = false;
});

const btnLeft = document.getElementById('btn-left');
const btnRight = document.getElementById('btn-right');

function bindButton(btn, keyName) {
    btn.addEventListener('touchstart', (e) => {
        e.preventDefault();
        keys[keyName] = true;
    }, { passive: false });

    btn.addEventListener('touchend', (e) => {
        e.preventDefault();
        keys[keyName] = false;
    });

    btn.addEventListener('mousedown', () => keys[keyName] = true);
    btn.addEventListener('mouseup', () => keys[keyName] = false);
    btn.addEventListener('mouseleave', () => keys[keyName] = false);
}

bindButton(btnLeft, 'ArrowLeft');
bindButton(btnRight, 'ArrowRight');

restartBtn.addEventListener('click', resetGame);

// --- Reset Game ---
function resetGame() {
    score = 0;
    coinsCollected = 0;
    roadSpeed = 6;
    frameCount = 0;
    isGameOver = false;
    obstacles = [];
    coins = [];

    player.x = LANES[1] - player.width / 2;
    player.tilt = 0;

    scoreEl.textContent = '0';
    coinEl.textContent = '0';
    gameOverScreen.classList.add('hidden');

    requestAnimationFrame(gameLoop);
}

// --- Spawning Logic ---
function spawnObstacle() {
    const laneIndex = Math.floor(Math.random() * 3);
    const laneCenter = LANES[laneIndex];
    const types = ['car', 'barricade', 'cone'];
    const type = types[Math.floor(Math.random() * types.length)];

    if (type === 'car') {
        const colors = ['#e74c3c', '#3498db', '#9b59b6', '#e67e22'];
        obstacles.push({
            type: 'car',
            width: 50,
            height: 82,
            x: laneCenter - 25,
            y: -100,
            speedOffset: -2.2, // Moves down slower than road so it looks like moving traffic
            color: colors[Math.floor(Math.random() * colors.length)]
        });
    } else if (type === 'barricade') {
        obstacles.push({
            type: 'barricade',
            width: 68,
            height: 26,
            x: laneCenter - 34,
            y: -60,
            speedOffset: 0
        });
    } else {
        obstacles.push({
            type: 'cone',
            width: 34,
            height: 34,
            x: laneCenter - 17,
            y: -60,
            speedOffset: 0
        });
    }
}

function spawnCoinRow() {
    const laneIndex = Math.floor(Math.random() * 3);
    const laneCenter = LANES[laneIndex];

    // Prevent spawning coins right on top of a newly spawned obstacle
    const blocked = obstacles.some(obs => obs.y < 120 && Math.abs((obs.x + obs.width / 2) - laneCenter) < 40);
    if (blocked) return;

    const count = 3;
    for (let i = 0; i < count; i++) {
        coins.push({
            x: laneCenter,
            y: -40 - (i * 45),
            radius: 14,
            angle: i * 0.5
        });
    }
}

// --- Collision Detection (with slight forgiving hitbox padding) ---
function isColliding(rect1, rect2) {
    const pad = 6;
    return (
        rect1.x + pad < rect2.x + rect2.width - pad &&
        rect1.x + rect1.width - pad > rect2.x + pad &&
        rect1.y + pad < rect2.y + rect2.height - pad &&
        rect1.y + rect1.height - pad > rect2.y + pad
    );
}

// --- Update Game Logic ---
function update() {
    frameCount++;

    // Gradually increase speed slightly as score climbs
    roadSpeed = 6 + Math.min(4, Math.floor(score / 500) * 0.5);

    // Scroll Road
    stripeOffset += roadSpeed;
    if (stripeOffset >= 80) stripeOffset = 0;

    // Update Distance Score
    if (frameCount % 6 === 0) {
        score += 1;
        scoreEl.textContent = score;
    }

    // Move Player
    const movingLeft = keys.ArrowLeft || keys.a;
    const movingRight = keys.ArrowRight || keys.d;

    if (movingLeft && !movingRight) {
        player.x -= player.speed;
        player.tilt = -0.08;
    } else if (movingRight && !movingLeft) {
        player.x += player.speed;
        player.tilt = 0.08;
    } else {
        player.tilt = 0;
    }

    const leftBound = ROAD_X + 8;
    const rightBound = ROAD_X + ROAD_WIDTH - player.width - 8;
    if (player.x < leftBound) player.x = leftBound;
    if (player.x > rightBound) player.x = rightBound;

    // Spawn Obstacles & Coins periodically
    if (frameCount % 65 === 0) {
        spawnObstacle();
    }
    if (frameCount % 110 === 0) {
        spawnCoinRow();
    }

    // Update Obstacles
    for (let i = obstacles.length - 1; i >= 0; i--) {
        const obs = obstacles[i];
        obs.y += roadSpeed + obs.speedOffset;

        // Check Crash
        if (isColliding(player, obs)) {
            triggerGameOver();
            return;
        }

        // Remove off-screen obstacles
        if (obs.y > GAME_HEIGHT + 100) {
            obstacles.splice(i, 1);
        }
    }

    // Update Coins
    for (let i = coins.length - 1; i >= 0; i--) {
        const coin = coins[i];
        coin.y += roadSpeed;
        coin.angle += 0.1;

        const coinBox = {
            x: coin.x - coin.radius,
            y: coin.y - coin.radius,
            width: coin.radius * 2,
            height: coin.radius * 2
        };

        // Check Coin Pickup
        if (isColliding(player, coinBox)) {
            coinsCollected += 1;
            score += 25;
            coinEl.textContent = coinsCollected;
            scoreEl.textContent = score;
            coins.splice(i, 1);
            continue;
        }

        if (coin.y > GAME_HEIGHT + 50) {
            coins.splice(i, 1);
        }
    }
}

function triggerGameOver() {
    isGameOver = true;
    finalScoreEl.textContent = score;
    finalCoinsEl.textContent = coinsCollected;
    gameOverScreen.classList.remove('hidden');
}

// --- Render Graphics ---
function drawEnvironment() {
    // Grass
    ctx.fillStyle = '#27ae60';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    ctx.fillStyle = '#2ecc71';
    for (let y = -80 + stripeOffset; y < GAME_HEIGHT; y += 80) {
        ctx.fillRect(0, y, GAME_WIDTH, 40);
    }

    // Road
    ctx.fillStyle = '#34495e';
    ctx.fillRect(ROAD_X, 0, ROAD_WIDTH, GAME_HEIGHT);

    // Curbs
    const curbWidth = 10;
    for (let y = -80 + stripeOffset; y < GAME_HEIGHT; y += 40) {
        ctx.fillStyle = (Math.floor((y - stripeOffset) / 40) % 2 === 0) ? '#e74c3c' : '#ecf0f1';
        ctx.fillRect(ROAD_X - curbWidth, y, curbWidth, 40);
        ctx.fillRect(ROAD_X + ROAD_WIDTH, y, curbWidth, 40);
    }

    // Lane Dividers
    ctx.fillStyle = '#f1c40f';
    const lane1X = ROAD_X + LANE_WIDTH;
    const lane2X = ROAD_X + LANE_WIDTH * 2;

    for (let y = -80 + stripeOffset; y < GAME_HEIGHT; y += 80) {
        ctx.fillRect(lane1X - 3, y, 6, 45);
        ctx.fillRect(lane2X - 3, y, 6, 45);
    }
}

function drawCoin(coin) {
    ctx.save();
    ctx.translate(coin.x, coin.y);
    // Horizontal scale effect to simulate 3D spinning
    const scaleX = Math.max(0.3, Math.abs(Math.cos(coin.angle)));
    ctx.scale(scaleX, 1);

    // Outer Gold Circle
    ctx.fillStyle = '#f1c40f';
    ctx.beginPath();
    ctx.arc(0, 0, coin.radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.lineWidth = 2.5;
    ctx.strokeStyle = '#d35400';
    ctx.stroke();

    // Inner Rupee Symbol
    ctx.fillStyle = '#d35400';
    ctx.font = 'bold 15px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('₹', 0, 1);

    ctx.restore();
}

function drawObstacle(obs) {
    if (obs.type === 'car') {
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
        ctx.beginPath();
        ctx.roundRect(obs.x + 3, obs.y + 5, obs.width, obs.height, 12);
        ctx.fill();

        // Wheels
        ctx.fillStyle = '#111';
        ctx.fillRect(obs.x - 3, obs.y + 12, 5, 16);
        ctx.fillRect(obs.x + obs.width - 2, obs.y + 12, 5, 16);
        ctx.fillRect(obs.x - 3, obs.y + obs.height - 28, 5, 16);
        ctx.fillRect(obs.x + obs.width - 2, obs.y + obs.height - 28, 5, 16);

        // Car Body
        ctx.fillStyle = obs.color;
        ctx.beginPath();
        ctx.roundRect(obs.x, obs.y, obs.width, obs.height, 12);
        ctx.fill();

        // Car Roof & Windows
        ctx.fillStyle = '#2c3e50';
        ctx.beginPath();
        ctx.roundRect(obs.x + 6, obs.y + 18, obs.width - 12, obs.height - 34, 6);
        ctx.fill();

        ctx.fillStyle = obs.color;
        ctx.beginPath();
        ctx.roundRect(obs.x + 9, obs.y + 28, obs.width - 18, obs.height - 52, 4);
        ctx.fill();

        // Taillights
        ctx.fillStyle = '#ff3f34';
        ctx.fillRect(obs.x + 6, obs.y + obs.height - 4, 10, 4);
        ctx.fillRect(obs.x + obs.width - 16, obs.y + obs.height - 4, 10, 4);

    } else if (obs.type === 'barricade') {
        // Metal Legs
        ctx.fillStyle = '#7f8c8d';
        ctx.fillRect(obs.x + 6, obs.y + 4, 6, obs.height - 4);
        ctx.fillRect(obs.x + obs.width - 12, obs.y + 4, 6, obs.height - 4);

        // Yellow & Black Striped Board
        ctx.fillStyle = '#f1c40f';
        ctx.beginPath();
        ctx.roundRect(obs.x, obs.y, obs.width, 16, 4);
        ctx.fill();

        ctx.fillStyle = '#1e272e';
        for (let sx = obs.x + 8; sx < obs.x + obs.width - 10; sx += 18) {
            ctx.fillRect(sx, obs.y, 9, 16);
        }

    } else if (obs.type === 'cone') {
        const cx = obs.x + obs.width / 2;
        const cy = obs.y + obs.height / 2;

        // Square Base
        ctx.fillStyle = '#e67e22';
        ctx.beginPath();
        ctx.roundRect(obs.x + 2, obs.y + 2, obs.width - 4, obs.height - 4, 6);
        ctx.fill();

        // White Reflective Ring
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(cx, cy, 10, 0, Math.PI * 2);
        ctx.fill();

        // Orange Tip
        ctx.fillStyle = '#d35400';
        ctx.beginPath();
        ctx.arc(cx, cy, 5, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawAutoRickshaw(x, y, width, height, tilt) {
    ctx.save();
    ctx.translate(x + width / 2, y + height / 2);
    ctx.rotate(tilt);

    const w = width;
    const h = height;
    const halfW = w / 2;
    const halfH = h / 2;

    // Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.beginPath();
    ctx.roundRect(-halfW + 3, -halfH + 6, w, h, 14);
    ctx.fill();

    // Rear Wheels
    ctx.fillStyle = '#111';
    ctx.fillRect(-halfW - 4, halfH - 26, 6, 20);
    ctx.fillRect(halfW - 2, halfH - 26, 6, 20);

    // Front Wheel
    ctx.fillRect(-4, -halfH - 5, 8, 16);

    // Front Mudguard
    ctx.fillStyle = '#f1c40f';
    ctx.beginPath();
    ctx.roundRect(-8, -halfH + 2, 16, 14, 6);
    ctx.fill();

    // Main Lower Body
    ctx.fillStyle = '#009432';
    ctx.beginPath();
    ctx.roundRect(-halfW, -halfH + 14, w, h - 16, [18, 18, 8, 8]);
    ctx.fill();

    // Yellow Racing Stripe
    ctx.fillStyle = '#f1c40f';
    ctx.fillRect(-halfW + 6, -halfH + 16, w - 12, 14);

    // Windshield Frame
    ctx.fillStyle = '#2c3e50';
    ctx.beginPath();
    ctx.roundRect(-halfW + 5, -halfH + 26, w - 10, 14, 4);
    ctx.fill();

    // Windshield Glass
    ctx.fillStyle = '#81ecec';
    ctx.beginPath();
    ctx.roundRect(-halfW + 8, -halfH + 28, w - 16, 10, 3);
    ctx.fill();

    // Black Canopy Roof
    ctx.fillStyle = '#1e272e';
    ctx.beginPath();
    ctx.roundRect(-halfW + 2, -halfH + 40, w - 4, h - 44, [4, 4, 8, 8]);
    ctx.fill();

    // Roof Ribs
    ctx.strokeStyle = '#485460';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-halfW + 6, -halfH + 54);
    ctx.lineTo(halfW - 6, -halfH + 54);
    ctx.moveTo(-halfW + 6, -halfH + 68);
    ctx.lineTo(halfW - 6, -halfH + 68);
    ctx.stroke();

    // Headlight
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(0, -halfH + 4, 4, 0, Math.PI * 2);
    ctx.fill();

    // Taillights
    ctx.fillStyle = '#ff3f34';
    ctx.fillRect(-halfW + 6, halfH - 4, 10, 4);
    ctx.fillRect(halfW - 16, halfH - 4, 10, 4);

    ctx.restore();
}

function draw() {
    ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
    drawEnvironment();

    coins.forEach(drawCoin);
    obstacles.forEach(drawObstacle);
    drawAutoRickshaw(player.x, player.y, player.width, player.height, player.tilt);
}

// --- Main Loop ---
function gameLoop() {
    if (isGameOver) return;

    update();
    draw();
    requestAnimationFrame(gameLoop);
}

// Start Game
gameLoop();