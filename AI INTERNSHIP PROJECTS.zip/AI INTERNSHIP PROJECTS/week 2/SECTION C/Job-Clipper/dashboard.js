const COLUMNS = ['Saved', 'Applied', 'Interview', 'Result'];
let allJobs = [];
let searchQuery = '';
let draggedJobId = null;

document.addEventListener('DOMContentLoaded', async () => {
  await loadJobs();
  setupEventListeners();
  setupDragAndDrop();
  renderBoard();

  // Keep dashboard synced if a new job is clipped from the popup while dashboard is open
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.savedJobs) {
      allJobs = normalizeJobs(changes.savedJobs.newValue || []);
      renderBoard();
    }
  });
});

/**
 * Ensures older jobs saved without a status default to "Saved"
 */
function normalizeJobs(jobs) {
  return jobs.map((job) => ({
    ...job,
    status: COLUMNS.includes(job.status) ? job.status : 'Saved',
  }));
}

/**
 * Load jobs from chrome.storage.local
 */
async function loadJobs() {
  try {
    const data = await chrome.storage.local.get({ savedJobs: [] });
    allJobs = normalizeJobs(data.savedJobs);
  } catch (error) {
    console.error('Failed to load jobs:', error);
    allJobs = [];
  }
}

/**
 * Persist all changes automatically to chrome.storage.local
 */
async function saveJobs(toastMessage = 'Changes saved') {
  try {
    await chrome.storage.local.set({ savedJobs: allJobs });
    showToast(toastMessage);
  } catch (error) {
    console.error('Failed to save jobs:', error);
    showToast('Error saving changes');
  }
}

/**
 * Render all four Kanban columns with current filter applied
 */
function renderBoard() {
  const filteredJobs = allJobs.filter((job) => {
    if (!searchQuery) return true;
    const term = searchQuery.toLowerCase();
    return (
      (job.jobTitle && job.jobTitle.toLowerCase().includes(term)) ||
      (job.companyName && job.companyName.toLowerCase().includes(term))
    );
  });

  COLUMNS.forEach((status) => {
    const container = document.getElementById(`col-${status}`);
    const countBadge = document.getElementById(`count-${status}`);
    const columnJobs = filteredJobs.filter((job) => job.status === status);

    countBadge.textContent = columnJobs.length;
    container.innerHTML = '';

    if (columnJobs.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty-state';
      empty.textContent = searchQuery ? 'No matching jobs' : 'Drop jobs here';
      container.appendChild(empty);
      return;
    }

    columnJobs.forEach((job) => {
      container.appendChild(createJobCard(job));
    });
  });
}

/**
 * Create a DOM card element for a job entry
 */
function createJobCard(job) {
  const card = document.createElement('article');
  card.className = 'job-card';
  card.draggable = true;
  card.dataset.id = job.id;

  // Drag events on card
  card.addEventListener('dragstart', (e) => {
    draggedJobId = job.id;
    card.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', job.id);
  });

  card.addEventListener('dragend', () => {
    draggedJobId = null;
    card.classList.remove('dragging');
    document.querySelectorAll('.column-cards').forEach((col) => {
      col.classList.remove('drag-over');
    });
  });

  // Top row: Job title & Edit/Delete actions
  const topRow = document.createElement('div');
  topRow.className = 'card-top';

  const titleEl = document.createElement('h3');
  titleEl.className = 'card-title';
  titleEl.textContent = job.jobTitle;

  const actionsEl = document.createElement('div');
  actionsEl.className = 'card-actions';

  const editBtn = document.createElement('button');
  editBtn.type = 'button';
  editBtn.className = 'card-action-btn';
  editBtn.textContent = 'Edit';
  editBtn.addEventListener('click', () => openModal(job));

  const deleteBtn = document.createElement('button');
  deleteBtn.type = 'button';
  deleteBtn.className = 'card-action-btn delete-btn';
  deleteBtn.textContent = 'Delete';
  deleteBtn.addEventListener('click', () => deleteJob(job.id));

  actionsEl.append(editBtn, deleteBtn);
  topRow.append(titleEl, actionsEl);

  // Company name
  const companyEl = document.createElement('p');
  companyEl.className = 'card-company';
  companyEl.textContent = job.companyName || 'Unknown Company';

  // Footer meta: Deadline & URL
  const metaEl = document.createElement('div');
  metaEl.className = 'card-meta';

  const deadlineEl = document.createElement('span');
  deadlineEl.className = 'card-deadline';
  if (job.applicationDeadline) {
    deadlineEl.textContent = `Due: ${formatDate(job.applicationDeadline)}`;
    if (isPastDue(job.applicationDeadline) && job.status !== 'Result') {
      deadlineEl.classList.add('overdue');
    }
  } else {
    deadlineEl.textContent = 'No deadline';
  }
  metaEl.appendChild(deadlineEl);

  if (job.jobUrl) {
    const linkEl = document.createElement('a');
    linkEl.className = 'card-link';
    linkEl.href = job.jobUrl;
    linkEl.target = '_blank';
    linkEl.rel = 'noopener noreferrer';
    linkEl.textContent = 'Open Link ↗';
    metaEl.appendChild(linkEl);
  }

  card.append(topRow, companyEl, metaEl);
  return card;
}

/**
 * Configure drop zones on all 4 Kanban columns
 */
function setupDragAndDrop() {
  const dropZones = document.querySelectorAll('.column-cards');

  dropZones.forEach((zone) => {
    zone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      zone.classList.add('drag-over');
    });

    zone.addEventListener('dragleave', (e) => {
      if (!zone.contains(e.relatedTarget)) {
        zone.classList.remove('drag-over');
      }
    });

    zone.addEventListener('drop', async (e) => {
      e.preventDefault();
      zone.classList.remove('drag-over');

      const jobId = e.dataTransfer.getData('text/plain') || draggedJobId;
      const newStatus = zone.dataset.status;

      if (!jobId || !COLUMNS.includes(newStatus)) return;

      const jobIndex = allJobs.findIndex((j) => j.id === jobId);
      if (jobIndex !== -1 && allJobs[jobIndex].status !== newStatus) {
        allJobs[jobIndex].status = newStatus;
        renderBoard();
        await saveJobs(`Moved to ${newStatus}`);
      }
    });
  });
}

/**
 * Set up search, modal, add job, and CSV export listeners
 */
function setupEventListeners() {
  const searchInput = document.getElementById('search-input');
  const addJobBtn = document.getElementById('add-job-btn');
  const exportCsvBtn = document.getElementById('export-csv-btn');
  const modalForm = document.getElementById('modal-job-form');
  const closeModalBtn = document.getElementById('close-modal-btn');
  const cancelModalBtn = document.getElementById('cancel-modal-btn');
  const modalBackdrop = document.getElementById('modal-backdrop');

  searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim();
    renderBoard();
  });

  addJobBtn.addEventListener('click', () => openModal(null));
  exportCsvBtn.addEventListener('click', exportToCSV);

  closeModalBtn.addEventListener('click', closeModal);
  cancelModalBtn.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', closeModal);

  modalForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const id = document.getElementById('edit-job-id').value;
    const jobTitle = document.getElementById('edit-job-title').value.trim();
    const companyName = document.getElementById('edit-company-name').value.trim();
    const applicationDeadline = document.getElementById('edit-deadline').value;
    const status = document.getElementById('edit-status').value;
    const jobUrl = document.getElementById('edit-job-url').value.trim();

    if (!jobTitle) return;

    if (id) {
      // Update existing job
      const index = allJobs.findIndex((j) => j.id === id);
      if (index !== -1) {
        allJobs[index] = {
          ...allJobs[index],
          jobTitle,
          companyName: companyName || 'Unknown Company',
          applicationDeadline,
          status,
          jobUrl,
        };
      }
      closeModal();
      renderBoard();
      await saveJobs('Job updated');
    } else {
      // Create new job directly from dashboard
      const newJob = {
        id: Date.now().toString(),
        jobTitle,
        companyName: companyName || 'Unknown Company',
        applicationDeadline,
        status,
        jobUrl,
        savedAt: new Date().toISOString(),
      };
      allJobs.unshift(newJob);
      closeModal();
      renderBoard();
      await saveJobs('Job added');
    }
  });
}

/**
 * Open modal for adding or editing a job
 */
function openModal(job = null) {
  const modal = document.getElementById('job-modal');
  const modalTitle = document.getElementById('modal-title');

  if (job) {
    modalTitle.textContent = 'Edit Job';
    document.getElementById('edit-job-id').value = job.id;
    document.getElementById('edit-job-title').value = job.jobTitle || '';
    document.getElementById('edit-company-name').value = job.companyName || '';
    document.getElementById('edit-deadline').value = job.applicationDeadline || '';
    document.getElementById('edit-status').value = job.status || 'Saved';
    document.getElementById('edit-job-url').value = job.jobUrl || '';
  } else {
    modalTitle.textContent = 'Add New Job';
    document.getElementById('edit-job-id').value = '';
    document.getElementById('modal-job-form').reset();
    document.getElementById('edit-status').value = 'Saved';
  }

  modal.classList.remove('hidden');
  document.getElementById('edit-job-title').focus();
}

function closeModal() {
  document.getElementById('job-modal').classList.add('hidden');
}

/**
 * Delete a job and save immediately
 */
async function deleteJob(jobId) {
  allJobs = allJobs.filter((job) => job.id !== jobId);
  renderBoard();
  await saveJobs('Job deleted');
}

/**
 * Export all saved jobs to a downloadable CSV file
 */
function exportToCSV() {
  if (allJobs.length === 0) {
    showToast('No jobs to export');
    return;
  }

  const headers = ['Job Title', 'Company Name', 'Status', 'Application Deadline', 'Job URL', 'Saved Date'];
  const rows = allJobs.map((job) => [
    escapeCSV(job.jobTitle),
    escapeCSV(job.companyName),
    escapeCSV(job.status),
    escapeCSV(job.applicationDeadline || ''),
    escapeCSV(job.jobUrl || ''),
    escapeCSV(job.savedAt ? job.savedAt.split('T')[0] : ''),
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = `job-clipper-export-${new Date().toISOString().split('T')[0]}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  showToast('CSV exported');
}

function escapeCSV(value) {
  const str = String(value ?? '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function formatDate(dateStr) {
  const [year, month, day] = dateStr.split('-');
  if (!year || !month || !day) return dateStr;
  return `${month}/${day}/${year}`;
}

function isPastDue(dateStr) {
  const today = new Date().toISOString().split('T')[0];
  return dateStr < today;
}

let toastTimer;
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.add('hidden');
  }, 2200);
}