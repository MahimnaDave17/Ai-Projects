document.addEventListener('DOMContentLoaded', async () => {
  const form = document.getElementById('job-clipper-form');
  const jobTitleInput = document.getElementById('job-title');
  const companyNameInput = document.getElementById('company-name');
  const deadlineInput = document.getElementById('application-deadline');
  const jobUrlInput = document.getElementById('job-url');
  const openDashboardBtn = document.getElementById('open-dashboard-btn');

  // Create and insert a status message element dynamically
  const statusMessage = document.createElement('p');
  statusMessage.id = 'status-message';
  statusMessage.style.cssText = 'font-size: 12px; margin-top: 8px; text-align: center; font-weight: 500; min-height: 16px;';
  form.appendChild(statusMessage);

  function showMessage(text, isError = false) {
    statusMessage.textContent = text;
    statusMessage.style.color = isError ? '#dc2626' : '#16a34a';
    setTimeout(() => {
      statusMessage.textContent = '';
    }, 3500);
  }

  // 1. Read active tab URL & 2-3. Detect Job Title and Company Name
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab) {
      if (tab.url && tab.url.startsWith('http')) {
        jobUrlInput.value = tab.url;
      }

      // Inject a lightweight script to inspect the DOM for headings and metadata
      if (tab.id && tab.url && tab.url.startsWith('http')) {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: extractJobDetailsFromPage,
        });

        const extracted = results?.[0]?.result;
        if (extracted) {
          if (extracted.jobTitle) jobTitleInput.value = extracted.jobTitle;
          if (extracted.companyName) companyNameInput.value = extracted.companyName;
        }
      }
    }
  } catch (error) {
    // Fails silently on restricted pages like chrome:// or extension pages
    console.warn('Could not auto-extract page details:', error);
  }

  // 5-7. Handle form submission, validation, and saving to chrome.storage.local
  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const jobTitle = jobTitleInput.value.trim();
    const companyName = companyNameInput.value.trim();
    const applicationDeadline = deadlineInput.value;
    const jobUrl = jobUrlInput.value.trim();

    // Prevent saving an empty job title
    if (!jobTitle) {
      showMessage('Please enter a job title before saving.', true);
      jobTitleInput.focus();
      return;
    }

    const newJob = {
      id: Date.now().toString(),
      jobTitle,
      companyName: companyName || 'Unknown Company',
      applicationDeadline,
      jobUrl,
      savedAt: new Date().toISOString(),
    };

    try {
      const data = await chrome.storage.local.get({ savedJobs: [] });
      const updatedJobs = [newJob, ...data.savedJobs];

      await chrome.storage.local.set({ savedJobs: updatedJobs });
      showMessage('Job saved successfully!');
    } catch (error) {
      console.error('Error saving job:', error);
      showMessage('Failed to save job. Please try again.', true);
    }
  });

  // 8. Open the dashboard page
  openDashboardBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
  });
});

/**
 * Function executed inside the active webpage context to extract
 * the job title and company name from headings, meta tags, or document title.
 */
function extractJobDetailsFromPage() {
  let jobTitle = '';
  let companyName = '';

  // 1. Try common job-board selectors first, then fallback to main <h1>
  const titleSelectors = [
    '[data-testid*="job-title"]',
    '[class*="job-title"]',
    '[class*="jobTitle"]',
    'h1',
  ];

  for (const selector of titleSelectors) {
    const el = document.querySelector(selector);
    if (el && el.innerText.trim().length > 2 && el.innerText.trim().length < 120) {
      jobTitle = el.innerText.trim().split('\n')[0];
      break;
    }
  }

  // 2. Try common company selectors or Open Graph site_name meta tag
  const companySelectors = [
    '[data-testid*="company"]',
    '[class*="company-name"]',
    '[class*="companyName"]',
    '[class*="employer"]',
  ];

  for (const selector of companySelectors) {
    const el = document.querySelector(selector);
    if (el && el.innerText.trim().length > 1 && el.innerText.trim().length < 80) {
      companyName = el.innerText.trim().split('\n')[0];
      break;
    }
  }

  if (!companyName) {
    const ogSiteName = document.querySelector('meta[property="og:site_name"]');
    if (ogSiteName && ogSiteName.content) {
      companyName = ogSiteName.content.trim();
    }
  }

  // 3. Fallback & cleanup using document.title (e.g., "Software Engineer at Acme | LinkedIn")
  const pageTitle = document.title || '';
  if (!jobTitle && pageTitle) {
    // Split on common title separators
    const parts = pageTitle.split(/\s+[\|\-–—]\s+/);
    const primaryPart = parts[0].trim();

    // Check for "Role at Company" pattern
    const atMatch = primaryPart.match(/^(.+?)\s+at\s+(.+)$/i);
    if (atMatch) {
      jobTitle = atMatch[1].trim();
      if (!companyName) companyName = atMatch[2].trim();
    } else {
      jobTitle = primaryPart;
      if (!companyName && parts.length > 1) {
        companyName = parts[1].trim();
      }
    }
  }

  return { jobTitle, companyName };
}