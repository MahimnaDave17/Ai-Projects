(() => {
    const DEFAULT_STATE = {
        settings: {
            hideShorts: true,
            hideRecs: true,
            hideComments: true
        },
        gate: {
            unlockedUntil: 0,
            reason: ''
        },
        studyList: [], // [{ id, title, url, done }]
        notesByVideo: {}, // { [videoId]: [{ id, seconds, label, text }] }
        dailyTime: {
            date: new Date().toISOString().slice(0, 10),
            seconds: 0
        }
    };

    let state = structuredClone(DEFAULT_STATE);

    // --- 1. Storage Helpers ---
    async function loadState() {
        const stored = await chrome.storage.local.get('yfbData');
        if (stored.yfbData) {
            state = {
                ...structuredClone(DEFAULT_STATE),
                ...stored.yfbData,
                settings: { ...DEFAULT_STATE.settings, ...(stored.yfbData.settings || {}) },
                gate: { ...DEFAULT_STATE.gate, ...(stored.yfbData.gate || {}) },
                dailyTime: stored.yfbData.dailyTime || DEFAULT_STATE.dailyTime
            };
        }
        // Reset daily counter if a new calendar day started
        const today = new Date().toISOString().slice(0, 10);
        if (state.dailyTime.date !== today) {
            state.dailyTime = { date: today, seconds: 0 };
            await saveState();
        }
    }

    async function saveState() {
        await chrome.storage.local.set({ yfbData: state });
    }

    // --- 2. Apply Distraction-Hiding Classes ---
    function applyDistractionRules() {
        document.body.classList.toggle('yfb-hide-shorts', state.settings.hideShorts);
        document.body.classList.toggle('yfb-hide-recs', state.settings.hideRecs);
        document.body.classList.toggle('yfb-hide-comments', state.settings.hideComments);
    }

    // --- 3. "Why Are You Here?" 60-Minute Gate ---
    function checkIntentionGate() {
        const now = Date.now();
        const existingOverlay = document.getElementById('yfb-gate-overlay');

        if (now < state.gate.unlockedUntil) {
            if (existingOverlay) existingOverlay.remove();
            return;
        }

        // Pause video if playing behind gate
        const video = document.querySelector('video');
        if (video && !video.paused) video.pause();

        if (existingOverlay) return;

        const overlay = document.createElement('div');
        overlay.id = 'yfb-gate-overlay';
        overlay.innerHTML = `
            <div class="yfb-gate-card">
                <span class="yfb-gate-badge">YOUTUBE FOCUS GATE</span>
                <h2>Why are you here?</h2>
                <p>State your study goal before entering YouTube. Unlocks distraction-free access for 60 minutes.</p>
                <input type="text" id="yfb-gate-reason" class="yfb-gate-input" placeholder="e.g., Revising Thermodynamics Lecture 2" />
                <button id="yfb-gate-submit" class="yfb-gate-btn">Unlock for 60 Minutes</button>
            </div>
        `;
        document.body.appendChild(overlay);

        const input = document.getElementById('yfb-gate-reason');
        const submitBtn = document.getElementById('yfb-gate-submit');

        const unlock = async () => {
            const text = input.value.trim();
            if (text.length < 3) {
                input.style.borderColor = '#ef4444';
                input.placeholder = 'Please enter a specific study reason...';
                return;
            }
            state.gate = {
                unlockedUntil: Date.now() + 60 * 60 * 1000,
                reason: text
            };
            await saveState();
            overlay.remove();
            renderBoard();
        };

        submitBtn.addEventListener('click', unlock);
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') unlock();
        });
    }

    // --- 4. Video ID & Timestamp Utilities ---
    function getCurrentVideoId() {
        const params = new URLSearchParams(window.location.search);
        return params.get('v');
    }

    function formatTimestamp(totalSec) {
        const s = Math.floor(totalSec);
        const hrs = Math.floor(s / 3600);
        const mins = Math.floor((s % 3600) / 60);
        const secs = String(s % 60).padStart(2, '0');
        return hrs > 0 ? `${hrs}:${String(mins).padStart(2, '0')}:${secs}` : `${mins}:${secs}`;
    }

    function getCleanVideoTitle() {
        const h1 = document.querySelector('h1.ytd-watch-metadata yt-formatted-string');
        if (h1 && h1.textContent.trim()) return h1.textContent.trim();
        return document.title.replace(' - YouTube', '').trim() || 'Untitled Lecture';
    }

    // --- 5. Render Floating Focus Board ---
    function ensureBoardExists() {
        if (document.getElementById('yfb-board')) return;

        const board = document.createElement('aside');
        board.id = 'yfb-board';
        board.innerHTML = `
            <div class="yfb-header">
                <div class="yfb-title">
                    <span>Focus Board</span>
                    <span id="yfb-today-time" class="yfb-timer-pill">Today: 0 min</span>
                </div>
                <button id="yfb-min-toggle" class="yfb-min-btn" title="Minimize/Expand">&minus;</button>
            </div>
            <div class="yfb-body">
                <div id="yfb-intention-box" class="yfb-intention-banner"></div>

                <!-- Quick Filter Switches -->
                <div>
                    <div class="yfb-section-title">Distraction Filters</div>
                    <div class="yfb-toggles">
                        <button class="yfb-chip" data-setting="hideShorts">Hide Shorts</button>
                        <button class="yfb-chip" data-setting="hideRecs">Hide Recs</button>
                        <button class="yfb-chip" data-setting="hideComments">Hide Comments</button>
                    </div>
                </div>

                <!-- Study List -->
                <div>
                    <div class="yfb-section-title">
                        <span>Study List</span>
                        <button id="yfb-add-video-btn" class="yfb-small-btn">+ Add Current</button>
                    </div>
                    <div id="yfb-study-list" class="yfb-list"></div>
                </div>

                <!-- Timestamp Notes for Current Video -->
                <div id="yfb-notes-section">
                    <div class="yfb-section-title">
                        <span>Timestamp Notes</span>
                        <span id="yfb-current-ts">0:00</span>
                    </div>
                    <div class="yfb-note-form">
                        <input type="text" id="yfb-note-input" class="yfb-note-input" placeholder="Note at current timestamp..." />
                        <button id="yfb-add-note-btn" class="yfb-small-btn">Save</button>
                    </div>
                    <div id="yfb-notes-list" class="yfb-list"></div>
                </div>
            </div>
        `;
        document.body.appendChild(board);

        // Minimize Toggle
        document.getElementById('yfb-min-toggle').addEventListener('click', () => {
            board.classList.toggle('yfb-minimized');
        });

        // Distraction Chip Toggles
        board.querySelectorAll('.yfb-chip').forEach((chip) => {
            chip.addEventListener('click', async () => {
                const key = chip.dataset.setting;
                state.settings[key] = !state.settings[key];
                await saveState();
                applyDistractionRules();
                renderBoard();
            });
        });

        // Add Current Video to Study List
        document.getElementById('yfb-add-video-btn').addEventListener('click', async () => {
            const vid = getCurrentVideoId();
            if (!vid) return alert('Open a video first to add it to your Study List.');
            if (state.studyList.some((item) => item.id === vid)) return;

            state.studyList.push({
                id: vid,
                title: getCleanVideoTitle(),
                url: `https://www.youtube.com/watch?v=${vid}`,
                done: false
            });
            await saveState();
            renderBoard();
        });

        // Add Timestamp Note
        const addNote = async () => {
            const vid = getCurrentVideoId();
            const video = document.querySelector('video');
            const input = document.getElementById('yfb-note-input');
            const text = input.value.trim();

            if (!vid || !video || !text) return;

            const seconds = Math.floor(video.currentTime);
            if (!state.notesByVideo[vid]) state.notesByVideo[vid] = [];

            state.notesByVideo[vid].push({
                id: Date.now().toString(),
                seconds,
                label: formatTimestamp(seconds),
                text
            });

            // Sort notes chronologically
            state.notesByVideo[vid].sort((a, b) => a.seconds - b.seconds);
            input.value = '';
            await saveState();
            renderBoard();
        };

        document.getElementById('yfb-add-note-btn').addEventListener('click', addNote);
        document.getElementById('yfb-note-input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') addNote();
        });
    }

    function renderBoard() {
        ensureBoardExists();

        // Update Time Spent Today
        const minsToday = Math.floor(state.dailyTime.seconds / 60);
        document.getElementById('yfb-today-time').textContent = `Today: ${minsToday} min`;

        // Update Intention Banner & Remaining Unlock Minutes
        const minsLeft = Math.max(0, Math.ceil((state.gate.unlockedUntil - Date.now()) / 60000));
        document.getElementById('yfb-intention-box').innerHTML = `
            <span>Goal: <strong>${state.gate.reason || 'Focused Study'}</strong></span>
            <span>${minsLeft}m left</span>
        `;

        // Update Toggle Chips
        document.querySelectorAll('.yfb-chip').forEach((chip) => {
            const key = chip.dataset.setting;
            chip.classList.toggle('active', Boolean(state.settings[key]));
        });

        // Render Study List
        const studyListEl = document.getElementById('yfb-study-list');
        studyListEl.innerHTML = '';
        if (state.studyList.length === 0) {
            studyListEl.innerHTML = '<div style="color:#64748b;font-size:12px;">No lectures added yet.</div>';
        } else {
            state.studyList.forEach((item, idx) => {
                const row = document.createElement('div');
                row.className = 'yfb-item';
                row.innerHTML = `
                    <div class="yfb-item-main">
                        <input type="checkbox" ${item.done ? 'checked' : ''} />
                        <a class="yfb-link ${item.done ? 'done' : ''}" href="${item.url}" title="${item.title}">${item.title}</a>
                    </div>
                    <button class="yfb-del-btn" title="Remove">&times;</button>
                `;

                row.querySelector('input').addEventListener('change', async (e) => {
                    state.studyList[idx].done = e.target.checked;
                    await saveState();
                    renderBoard();
                });

                row.querySelector('.yfb-del-btn').addEventListener('click', async () => {
                    state.studyList.splice(idx, 1);
                    await saveState();
                    renderBoard();
                });

                studyListEl.appendChild(row);
            });
        }

        // Render Timestamp Notes for Active Video
        const vid = getCurrentVideoId();
        const notesSection = document.getElementById('yfb-notes-section');
        const notesListEl = document.getElementById('yfb-notes-list');

        if (!vid) {
            notesSection.style.display = 'none';
            return;
        }

        notesSection.style.display = 'block';
        notesListEl.innerHTML = '';
        const notes = state.notesByVideo[vid] || [];

        if (notes.length === 0) {
            notesListEl.innerHTML = '<div style="color:#64748b;font-size:12px;">No timestamp notes on this video.</div>';
        } else {
            notes.forEach((note, idx) => {
                const row = document.createElement('div');
                row.className = 'yfb-item';
                row.innerHTML = `
                    <div class="yfb-item-main">
                        <span class="yfb-ts-badge">${note.label}</span>
                        <span class="yfb-link" title="${note.text}">${note.text}</span>
                    </div>
                    <button class="yfb-del-btn" title="Delete note">&times;</button>
                `;

                // Jump video to exact timestamp on click
                row.querySelector('.yfb-ts-badge').addEventListener('click', () => {
                    const video = document.querySelector('video');
                    if (video) {
                        video.currentTime = note.seconds;
                        video.play();
                    }
                });

                row.querySelector('.yfb-del-btn').addEventListener('click', async () => {
                    state.notesByVideo[vid].splice(idx, 1);
                    await saveState();
                    renderBoard();
                });

                notesListEl.appendChild(row);
            });
        }
    }

    // --- 6. Live Ticker (Tracks Study Time, Live Video Timestamp & Gate Expiry) ---
    setInterval(async () => {
        if (document.hidden) return;

        // Track active time on YouTube
        state.dailyTime.seconds += 1;
        if (state.dailyTime.seconds % 10 === 0) {
            await saveState();
        }

        const minsToday = Math.floor(state.dailyTime.seconds / 60);
        const timePill = document.getElementById('yfb-today-time');
        if (timePill) timePill.textContent = `Today: ${minsToday} min`;

        // Update live current video timestamp indicator
        const video = document.querySelector('video');
        const tsEl = document.getElementById('yfb-current-ts');
        if (video && tsEl) {
            tsEl.textContent = formatTimestamp(video.currentTime);
        }

        // Re-lock gate after 60 minutes expire
        checkIntentionGate();
    }, 1000);

    // Listen for changes from Extension Popup
    chrome.storage.onChanged.addListener((changes) => {
        if (changes.yfbData && changes.yfbData.newValue) {
            state = changes.yfbData.newValue;
            applyDistractionRules();
            renderBoard();
            checkIntentionGate();
        }
    });

    // --- 7. Handle YouTube SPA Navigation (No Full Reloads) ---
    async function onRouteChange() {
        await loadState();
        applyDistractionRules();
        checkIntentionGate();
        renderBoard();
    }

    window.addEventListener('yt-navigate-finish', onRouteChange);
    onRouteChange();
})();