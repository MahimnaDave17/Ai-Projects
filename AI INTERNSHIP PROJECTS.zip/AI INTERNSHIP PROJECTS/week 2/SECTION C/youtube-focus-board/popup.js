document.addEventListener('DOMContentLoaded', async () => {
    const stored = await chrome.storage.local.get('yfbData');
    const data = stored.yfbData || {
        settings: { hideShorts: true, hideRecs: true, hideComments: true },
        gate: { unlockedUntil: 0, reason: '' },
        dailyTime: { date: new Date().toISOString().slice(0, 10), seconds: 0 }
    };

    const chkShorts = document.getElementById('chk-shorts');
    const chkRecs = document.getElementById('chk-recs');
    const chkComments = document.getElementById('chk-comments');

    chkShorts.checked = data.settings.hideShorts;
    chkRecs.checked = data.settings.hideRecs;
    chkComments.checked = data.settings.hideComments;

    const mins = Math.floor((data.dailyTime?.seconds || 0) / 60);
    document.getElementById('popup-time').textContent = `Today: ${mins} min`;

    async function updateSettings() {
        data.settings.hideShorts = chkShorts.checked;
        data.settings.hideRecs = chkRecs.checked;
        data.settings.hideComments = chkComments.checked;
        await chrome.storage.local.set({ yfbData: data });
    }

    chkShorts.addEventListener('change', updateSettings);
    chkRecs.addEventListener('change', updateSettings);
    chkComments.addEventListener('change', updateSettings);

    document.getElementById('lock-now-btn').addEventListener('click', async () => {
        data.gate.unlockedUntil = 0;
        await chrome.storage.local.set({ yfbData: data });
        window.close();
    });
});