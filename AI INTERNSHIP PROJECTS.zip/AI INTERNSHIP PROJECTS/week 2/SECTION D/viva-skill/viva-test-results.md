# /viva - test results

How these were run: I played the skill (reading SKILL.md and following it) and a scripted student whose answers are identical in the with-skill and without-skill runs. Student answers are simulated by me, so this tests the skill's behaviour, not a real person. 5 questions per run.

Task given in every run: "/viva 5" + the notes (baseline: "Ask me viva questions from these notes, 5 of them, then score me").

---

## Fresh-session start check (first message only, nothing else in context)

**Input: `/viva` with no notes**
> Paste or upload the notes (or name the topic) you want to be examined on.

**Input: `/viva 5` + DBMS notes** (first turn of Test A below)
> **Viva: Database normalization** - 5 questions, one at a time. Answer like you would aloud (2-4 sentences). Say `hint`, `skip`, or `stop` anytime.
> **Q1/5** What problem does normalization solve? Name the three anomalies.

Result: starts immediately, no setup questions when notes exist, exactly one question, asks for notes in one line when they don't.

---

## Test A - DBMS notes (strong student)

Notes: normalization, 1NF-BCNF, anomalies, Student(RollNo, Course, Instructor) example, denormalization.

### With skill
**Q1/5** What problem does normalization solve? Name the three anomalies.
> Student: It removes redundancy; insertion, deletion and update anomalies.

Q1: 2/2 - correct and complete.
**Q2/5** What is a partial dependency, and which normal form removes it?
> Student: A non-key attribute depending on only part of a composite key. 2NF removes it.

Q2: 2/2.
**Q3/5** Orders(OrderID, ProductID, ProductName, Qty) with key (OrderID, ProductID). Which normal form is violated and why?
> Student: 3NF, because there's a dependency.

Q3: 0/2 so far - "3NF" is not it and "a dependency" is not an explanation. Look at the key again: is it composite? What does ProductName actually depend on?
> Student: Oh - ProductName depends only on ProductID, which is part of the key. So 2NF.

Q3: 1/2 after probe (capped at 1).
**Q4/5** Using the Student(RollNo, Course, Instructor) example with Instructor -> Course, explain how 3NF differs from BCNF.
> Student: BCNF needs every determinant to be a superkey. Instructor isn't, so it fails BCNF but passes 3NF.

Q4: 2/2.
**Q5/5** Why would a real system deliberately denormalize?
> Student: For faster reads, joins are costly.

Q5: 1/2 - gives the reason but not the price paid.

**Score: 8/10 (80%) - Almost there**

| Q | Topic | Score | Gap |
|---|---|---|---|
| 1 | Anomalies | 2 | - |
| 2 | Partial dependency / 2NF | 2 | - |
| 3 | Spotting 2NF violation | 1 | Needed a probe to find the partial dependency |
| 4 | 3NF vs BCNF | 2 | - |
| 5 | Denormalization | 1 | Missed the trade-off: redundancy and anomalies return |

**Revisit first:** applying 2NF to a composite-key table (notes: 2NF section); denormalization trade-off.
**If the examiner asks this again (Q3):** First check the key. It is composite (OrderID, ProductID). ProductName depends on ProductID alone, a part of the key. That is a partial dependency, so the table violates 2NF. Fix: move ProductName into a Product table.
Want a retry on just those two?

### Without skill
> Here are 5 viva questions: 1. What is normalization and why is it used? 2. Explain 1NF, 2NF and 3NF. 3. What is a partial dependency? 4. Difference between 3NF and BCNF? 5. What is denormalization? Send your answers and I'll score you.

(Student sends all five answers at once, same content as above.)
> Q1 good. Q2 you didn't answer. Q3 good. Q4 good. Q5 partly. Score: 7/10. Revise denormalization.

---

## Test B - Operating Systems notes (weak student)

Notes: FCFS (convoy effect), SJF (optimal avg wait, starvation), Round Robin (quantum), aging.

### With skill
**Q1/5** What is the convoy effect, and in which algorithm does it occur?
> Student: In FCFS, processes wait.

Q1: 0/2 so far - true but not the effect. What exactly is waiting, and behind what?
> Student: Short jobs wait behind a long job.

Q1: 1/2 after probe.
**Q2/5** SJF gives the lowest average waiting time. Why isn't it used as-is in real systems?
> Student: It's the fastest so it should be used.

Q2: 0/2 - that restates the claim and misses both problems. Probe: what must the scheduler know in advance, and what happens to a very long job if short ones keep arriving?
> Student: Not sure.

Q2: 0/2. (Needs burst-time prediction; long jobs can starve.)
**Q3/5** What happens to Round Robin if the time quantum is very small? Very large?
> Student: Small quantum makes it slow because it keeps switching. Large I don't remember.

Q3: 1/2 - small quantum correct (context-switch overhead); large quantum becomes FCFS.
**Q4/5** What is starvation, and how does aging fix it?
> Student: I don't know.

Q4: 0/2. Starvation: a process waits indefinitely while others are always chosen. Aging gradually raises the priority of waiting processes.
**Q5/5** For an interactive system, which algorithm would you choose and why?
> Student: Round Robin because it's fair.

Q5: 1/2 - right choice, thin reason (no mention of response time / preemption).

**Score: 3/10 (30%) - Re-read first**

| Q | Topic | Score | Gap |
|---|---|---|---|
| 1 | Convoy effect | 1 | Needed probe |
| 2 | SJF limits | 0 | Burst prediction + starvation unknown |
| 3 | RR quantum | 1 | Large-quantum case missing |
| 4 | Starvation / aging | 0 | Not known |
| 5 | Interactive choice | 1 | "Fair" is not a reason |

**Revisit first:** SJF drawbacks, starvation and aging (notes: SJF + aging sections); RR quantum extremes.
**If the examiner asks this again (Q2):** SJF is optimal for average waiting time, but it needs each job's burst time in advance, which can only be estimated. Also, if short jobs keep arriving, a long job may never run - starvation. That is why aging or other priority fixes are used.
Want a retry on just those?

### Without skill
> Questions: 1. Explain FCFS. 2. Explain SJF. 3. Explain Round Robin. 4. What is starvation? 5. Convoy effect? Reply with answers and I'll give a score.

(Student sends the same answers.)
> Score: 4/10. Q1 partly right, Q2 incorrect, Q3 partly right, Q4 not answered, Q5 partly right. Study scheduling algorithms again.

---

## Test C - Networking notes (mixed student)

Notes: three-way handshake, 4-step teardown, TCP vs UDP, /26 subnet maths, TCP/IP vs OSI.

### With skill
**Q1/5** Describe the TCP three-way handshake. Why three steps?
> Student: SYN, SYN-ACK, ACK. Both sides confirm they can send and receive before data flows.

Q1: 2/2.
**Q2/5** Compare TCP and UDP, with one use for each.
> Student: TCP is reliable and ordered, UDP is faster with no guarantee.

Q2: 1/2 - comparison fine, but you gave no use case for either.
**Q3/5** How many usable hosts in a /26, and why minus two?
> Student: 62. Network and broadcast addresses are reserved.

Q3: 2/2.
**Q4/5** Which /26 subnet does 192.168.1.70 fall in, and what is its broadcast address?
> Student: 192.168.1.0/26, broadcast .63.

Q4: 0/2 so far. Each /26 block is 64 wide: .0, .64, .128 ... where does .70 fall?
> Student: .64 subnet. Broadcast would be .128.

Q4: 1/2 after probe (subnet fixed; broadcast is .127, not .128).
**Q5/5** Why does connection teardown use four steps, when setup uses three?
> Student: Because each side has to close its own direction.

Q5: 1/2 - right idea, needs FIN/ACK per direction spelled out.

**Score: 7/10 (70%) - Almost there**

| Q | Topic | Score | Gap |
|---|---|---|---|
| 1 | Handshake | 2 | - |
| 2 | TCP vs UDP | 1 | No use cases |
| 3 | Usable hosts | 2 | - |
| 4 | Subnet lookup | 1 | Block-size method shaky; broadcast = next network - 1 |
| 5 | Teardown | 1 | Not spelled out |

**Revisit first:** locating an IP in its block (notes: subnet section); FIN/ACK teardown.
**If the examiner asks this again (Q4):** /26 blocks are 64 wide. .70 lies in 192.168.1.64/26 (.64-.127). Broadcast is the last address, .127. Usable hosts are .65-.126.
Want a retry on just those two?

### Without skill
> 1. Explain the three-way handshake. 2. TCP vs UDP? 3. What is subnetting? 4. Find usable hosts in /26. 5. OSI vs TCP/IP layers? Send answers for scoring.

(Student sends the same answers.)
> 6/10. Good on handshake and hosts. Be more detailed on UDP and subnetting.

---

## Checklist: with skill vs without (3 runs each)

| Behaviour | With skill | Without |
|---|---|---|
| Starts without setup questions when notes are given | 3/3 | 3/3 |
| One question at a time | 3/3 | 0/3 (all 5 dumped) |
| Questions escalate recall -> apply -> trade-off | 3/3 | 0/3 |
| Probes a weak answer before moving on | 3/3 | 0/3 |
| Handles "I don't know" correctly (answer, 0, move on) | 1/1 | 0/1 |
| Per-answer score with a stated reason | 3/3 | 0/3 |
| Final scorecard with band | 3/3 | 0/3 |
| Names weak topics tied to the notes | 3/3 | 0/3 |
| Model answer for weakest question | 3/3 | 0/3 |
| Questions answerable only from notes | 3/3 | 2/3 (asked "what is subnetting?", not in notes) |

Honest limits: single runs, simulated student, and I wrote both sides, so I know the skill's intent. Real use may expose edge cases (very long notes, notes with errors, a student who pastes several answers at once). I left the note-error flag untested.
